import 'package:isar/isar.dart';
import '../database/isar_service.dart';
import '../../features/home/data/blood_pressure_model.dart';

class PressureRepository {
  final IsarService _isarService;

  PressureRepository(this._isarService);

  // Стрим для главного экрана
  Stream<List<BloodPressureRecord>> getAllRecordsStream() async* {
    final isar = await _isarService.db;
    yield* isar.bloodPressureRecords
        .where()
        .sortByDateTimeDesc()
        .watch(fireImmediately: true);
  }

  // МЕТОД ЗАПИСИ (Исправляет ошибку в AddRecordBloc)
  Future<void> addRecord(BloodPressureRecord record) async {
    final isar = await _isarService.db;
    await isar.writeTxn(() async {
      await isar.bloodPressureRecords.put(record);
    });
  }

  // Метод для получения списка (для аналитики или экспорта)
  Future<List<BloodPressureRecord>> getAllRecords() async {
    final isar = await _isarService.db;
    return await isar.bloodPressureRecords
        .where()
        .sortByDateTimeDesc()
        .findAll();
  }

  // МЕТОД УДАЛЕНИЯ (пригодится для Dismissible)
  Future<void> deleteRecord(int id) async {
    final isar = await _isarService.db;
    await isar.writeTxn(() async {
      await isar.bloodPressureRecords.delete(id);
    });
  }
}
