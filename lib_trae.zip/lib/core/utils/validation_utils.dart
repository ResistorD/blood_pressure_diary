class ValidationUtils {
  static const int minSys = 70;
  static const int maxSys = 250;
  static const int minDia = 40;
  static const int minPulse = 30;
  static const int maxPulse = 200;

  // Главный метод: можно ли добавить эту цифру?
  static bool isDigitAllowed({
    required String currentText,
    required String digit,
    required String fieldType, // 'SYS', 'DIA', 'PUL'
    int? systolicValue,        // Нужно для проверки DIA < SYS
  }) {
    final String newText = currentText + digit;
    final int? newVal = int.tryParse(newText);

    if (newVal == null) return false;
    if (newText.length > 3) return false;

    // 1. Правило первой цифры (не может быть 0)
    if (currentText.isEmpty && digit == '0') return false;

    // 2. Логика по полям
    switch (fieldType) {
      case 'SYS':
        if (newText.length == 1) return [7, 8, 9, 1, 2].contains(newVal);
        return newVal <= maxSys;

      case 'DIA':
        if (newText.length == 1) return [4, 5, 6, 7, 8, 9, 1].contains(newVal);
        // ЗОЛОТОЕ ПРАВИЛО: DIA < SYS
        if (systolicValue != null && newVal >= systolicValue) return false;
        return newVal <= 150;

      case 'PUL':
        if (newText.length == 1) return [3, 4, 5, 6, 7, 8, 9, 1, 2].contains(newVal);
        return newVal <= maxPulse;

      default:
        return true;
    }
  }

  /// Валидирует форму записи давления
  /// Возвращает true, если все поля заполнены корректно
  static bool isFormValid({
    required String systolic,
    required String diastolic,
    required String pulse,
  }) {
    final sys = int.tryParse(systolic) ?? 0;
    final dia = int.tryParse(diastolic) ?? 0;
    final pul = int.tryParse(pulse) ?? 0;

    return sys >= minSys && dia >= minDia && pul >= minPulse;
  }
}