import 'package:flutter/material.dart';

double _clamp(double v, double min, double max) => v < min ? min : (v > max ? max : v);

/// Базовая ширина макета из Figma
const double _designWidth = 360;

/// Масштаб по ширине экрана (в разумных пределах).
/// Важно: это не «scale-вёрстка», а мягкая адаптация dp/sp под разные ширины.
double _wScale(BuildContext context) {
  final w = MediaQuery.sizeOf(context).width;
  return _clamp(w / _designWidth, 0.90, 3.0);
}

/// dp для размеров/отступов
double dp(BuildContext context, double value) => value * _wScale(context);

/// sp для текста (НЕ уважает системный размер шрифта)
double sp(BuildContext context, double value) => value * _wScale(context);
