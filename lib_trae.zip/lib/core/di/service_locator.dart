import 'package:get_it/get_it.dart';
import '../../features/home/presentation/bloc/home_bloc.dart';
import '../database/isar_service.dart';
import '../repositories/pressure_repository.dart';
import '../../features/add_record/presentation/bloc/add_record_bloc.dart';

final getIt = GetIt.instance;

Future<void> setupLocator() async {
  // 1. База данных
  getIt.registerSingleton<IsarService>(IsarService());

  // 2. Репозиторий (зависит от IsarService)
  getIt.registerLazySingleton<PressureRepository>(
        () => PressureRepository(getIt<IsarService>()),
  );

  // 3. BLoC (зависит от репозитория)
  // Используем registerFactory, чтобы при каждом открытии экрана был свежий BLoC
  getIt.registerFactory(() => HomeBloc(getIt<PressureRepository>()));
  getIt.registerFactory(() => AddRecordBloc(getIt<PressureRepository>()));
}