import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';
import '../../features/home/data/blood_pressure_model.dart';

class IsarService {
  late Future<Isar> db;

  IsarService() {
    db = openDB();
  }

  Future<Isar> openDB() async {
    if (Isar.instanceNames.isEmpty) {
      final dir = await getApplicationDocumentsDirectory();
      return await Isar.open(
        [BloodPressureRecordSchema], // Та самая схема из генератора
        directory: dir.path,
      );
    }
    return Isar.getInstance()!;
  }

  // Метод для записи
  Future<void> saveRecord(BloodPressureRecord record) async {
    final isar = await db;
    await isar.writeTxn(() async {
      await isar.bloodPressureRecords.put(record);
    });
  }

  // Стрим для прослушивания изменений (реактивщина!)
  Stream<List<BloodPressureRecord>> listenToRecords() async* {
    final isar = await db;
    yield* isar.bloodPressureRecords
        .where()
        .sortByDateTimeDesc()
        .watch(fireImmediately: true);
  }
}