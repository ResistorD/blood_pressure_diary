import 'package:flutter/material.dart';
import 'package:isar/isar.dart';

part 'blood_pressure_model.g.dart';

@Collection()
class BloodPressureRecord {
  Id id = Isar.autoIncrement;

  @Index()
  late DateTime dateTime;
  late int systolic;
  late int diastolic;
  late int pulse;

  String? note;    // Поле для заметок (бывший comment)
  String? emotion; // Твой эмодзи

  @ignore
  Color get statusColor {
    // Единая система статусов (как в «свежем» UI):
    // - красный: повышенное
    // - голубой: пониженное
    // - зелёный: остальное
    if (systolic >= 140 || diastolic >= 90) return const Color(0xFFE11D48);
    if (systolic <= 100 || diastolic <= 60) return const Color(0xFF60A5FA);
    return const Color(0xFF22C55E);
  }

  @ignore
  String get statusText {
    if (systolic >= 140 || diastolic >= 90) return 'Повышено';
    if (systolic <= 100 || diastolic <= 60) return 'Понижено';
    return 'Норма';
  }
}
