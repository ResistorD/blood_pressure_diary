import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import '../../../../core/theme/app_theme.dart';
import '../data/blood_pressure_model.dart';
import 'bloc/home_bloc.dart';
import 'bloc/home_state.dart';

class StatisticsScreen extends StatelessWidget {
  const StatisticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppUI.background,
      appBar: AppBar(
        title: const Text('Графики', style: TextStyle(color: Colors.black, fontFamily: 'Inter', fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
      ),
      body: BlocBuilder<HomeBloc, HomeState>(
        builder: (context, state) {
          if (state is HomeLoaded) {
             if (state.records.isEmpty) return const Center(child: Text("Нет данных для отображения графиков"));
             return Padding(
               padding: const EdgeInsets.all(16.0),
               child: _PressureChart(records: state.records),
             );
          }
          return const Center(child: CircularProgressIndicator());
        },
      ),
    );
  }
}

class _PressureChart extends StatelessWidget {
  final List<BloodPressureRecord> records;
  const _PressureChart({required this.records});

  @override
  Widget build(BuildContext context) {
    // Sort records by date
    final sorted = List<BloodPressureRecord>.from(records)..sort((a, b) => a.dateTime.compareTo(b.dateTime));
    // Take last 20 points for better visibility if too many
    final displayRecords = sorted.length > 20 ? sorted.sublist(sorted.length - 20) : sorted;

    final spotsSys = displayRecords.asMap().entries.map((e) {
      return FlSpot(e.key.toDouble(), e.value.systolic.toDouble());
    }).toList();

    final spotsDia = displayRecords.asMap().entries.map((e) {
      return FlSpot(e.key.toDouble(), e.value.diastolic.toDouble());
    }).toList();

    return Column(
      children: [
        const Text("Динамика давления", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        Expanded(
          child: LineChart(
            LineChartData(
              gridData: const FlGridData(show: true, drawVerticalLine: false),
              titlesData: FlTitlesData(
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      final index = value.toInt();
                      if (index >= 0 && index < displayRecords.length) {
                         // Show date for every 5th item or first/last
                         if (index == 0 || index == displayRecords.length - 1 || index % 5 == 0) {
                           return Padding(
                             padding: const EdgeInsets.only(top: 8.0),
                             child: Text(
                               DateFormat('d MMM').format(displayRecords[index].dateTime),
                               style: const TextStyle(fontSize: 10),
                             ),
                           );
                         }
                      }
                      return const SizedBox.shrink();
                    },
                    interval: 1,
                  ),
                ),
                leftTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: true, reservedSize: 30),
                ),
                topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              ),
              borderData: FlBorderData(show: true, border: Border.all(color: Color(0x1F000000))),
              minX: 0,
              maxX: (displayRecords.length - 1).toDouble(),
              minY: 40,
              maxY: 200,
              lineBarsData: [
                LineChartBarData(
                  spots: spotsSys,
                  isCurved: true,
                  color: Colors.redAccent,
                  barWidth: 3,
                  isStrokeCapRound: true,
                  dotData: const FlDotData(show: true),
                  belowBarData: BarAreaData(show: false),
                ),
                LineChartBarData(
                  spots: spotsDia,
                  isCurved: true,
                  color: Colors.blueAccent,
                  barWidth: 3,
                  isStrokeCapRound: true,
                  dotData: const FlDotData(show: true),
                  belowBarData: BarAreaData(show: false),
                ),
              ],
              lineTouchData: LineTouchData(
                touchTooltipData: LineTouchTooltipData(
                  getTooltipItems: (touchedSpots) {
                    return touchedSpots.map((spot) {
                      return LineTooltipItem(
                        '${spot.y.toInt()}',
                        const TextStyle(color: Colors.white),
                      );
                    }).toList();
                  },
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _LegendItem(color: AppUI.accentRed, text: "Систолическое"),
            const SizedBox(width: 20),
            _LegendItem(color: AppUI.primaryBlue, text: "Диастолическое"),
          ],
        ),
      ],
    );
  }
}

class _LegendItem extends StatelessWidget {
  final Color color;
  final String text;
  const _LegendItem({required this.color, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 12, height: 12, color: color),
        const SizedBox(width: 4),
        Text(text, style: const TextStyle(fontSize: 12)),
      ],
    );
  }
}
