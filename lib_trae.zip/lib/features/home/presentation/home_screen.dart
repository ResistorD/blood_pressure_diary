import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/theme/scale.dart';
import '../data/blood_pressure_model.dart';
import 'bloc/home_bloc.dart';
import 'bloc/home_state.dart';
import 'widgets/summary_card.dart';
import 'widgets/record_list_item.dart';
import '../../add_record/presentation/add_record_screen.dart';

enum _FilterPeriod { today, week, month, all }

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const _prefKey = 'home_filter_period';
  _FilterPeriod _period = _FilterPeriod.week;

  @override
  void initState() {
    super.initState();
    _loadFilterPeriod();
  }

  Future<void> _loadFilterPeriod() async {
    final prefs = await SharedPreferences.getInstance();
    final idx = prefs.getInt(_prefKey) ?? _FilterPeriod.week.index;
    if (!mounted) return;
    setState(() => _period = _FilterPeriod.values[idx.clamp(0, _FilterPeriod.values.length - 1)]);
  }

  Future<void> _saveFilterPeriod(_FilterPeriod period) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_prefKey, period.index);
  }

  String _periodLabel(_FilterPeriod p) {
    switch (p) {
      case _FilterPeriod.today:
        return 'Сегодня';
      case _FilterPeriod.week:
        return 'Неделя';
      case _FilterPeriod.month:
        return 'Месяц';
      case _FilterPeriod.all:
        return 'Всё';
    }
  }

  String _recordsWord(int n) {
    final nAbs = n.abs() % 100;
    final n1 = nAbs % 10;
    if (nAbs >= 11 && nAbs <= 19) return 'записей';
    if (n1 == 1) return 'запись';
    if (n1 >= 2 && n1 <= 4) return 'записи';
    return 'записей';
  }

  List<BloodPressureRecord> _applyFilter(List<BloodPressureRecord> records) {
    final now = DateTime.now();
    switch (_period) {
      case _FilterPeriod.today:
        final d = DateTime(now.year, now.month, now.day);
        return records.where((r) {
          final rd = DateTime(r.dateTime.year, r.dateTime.month, r.dateTime.day);
          return rd == d;
        }).toList();
      case _FilterPeriod.week:
        final from = now.subtract(const Duration(days: 7));
        return records.where((r) => r.dateTime.isAfter(from)).toList();
      case _FilterPeriod.month:
        final from = now.subtract(const Duration(days: 30));
        return records.where((r) => r.dateTime.isAfter(from)).toList();
      case _FilterPeriod.all:
        return records;
    }
  }

  void _openAdd(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const AddRecordScreen()));
  }

  void _openEdit(BuildContext context, BloodPressureRecord record) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => AddRecordScreen(record: record)));
  }

  @override
  Widget build(BuildContext context) {
    final safeTop = MediaQuery.of(context).padding.top;

    // ── Figma (360w) → dp/sp ────────────────────────────────────────────────
    final blueH = dp(context, 169);
    final lightH = dp(context, 82);
    final overlap = dp(context, 50);

    final side = dp(context, 20);

    final titleFont = sp(context, 26);
    final filterFont = sp(context, 16);

    return BlocBuilder<HomeBloc, HomeState>(
      builder: (context, state) {
        final all = state is HomeLoaded ? state.records : const <BloodPressureRecord>[];
        final records = _applyFilter(all)..sort((a, b) => b.dateTime.compareTo(a.dateTime));
        final filteredCount = records.length;

        final lastRecord = all.isNotEmpty
            ? (List<BloodPressureRecord>.from(all)..sort((a, b) => b.dateTime.compareTo(a.dateTime))).first
            : null;

        final groups = _groupByDate(records);

        // ── Шапка (теперь внутри BlocBuilder, чтобы видеть filteredCount) ────
        final header = SizedBox(
          height: blueH + lightH,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              // Синий фон
              const Positioned.fill(child: ColoredBox(color: AppUI.headerBlue)),

              // Светлая полка
              Positioned(
                left: 0,
                right: 0,
                top: blueH,
                height: lightH,
                child: Stack(
                  children: const [
                    Positioned.fill(child: ColoredBox(color: Color(0xFFF9F8FA))),
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      height: 0.5,
                      child: ColoredBox(color: Color(0x33000000)),
                    ),
                  ],
                ),
              ),

              // Заголовок + счётчик + фильтр
              Positioned(
                left: side,
                right: side,
                top: safeTop + dp(context, 20),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Мой дневник',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: titleFont,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Inter',
                              height: 1.0,
                            ),
                          ),
                          SizedBox(height: dp(context, 20)),
                          Text(
                            '$filteredCount ${_recordsWord(filteredCount)}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: const Color(0xFFBFD4E7),
                              fontSize: sp(context, 16),
                              fontWeight: FontWeight.w500,
                              fontFamily: 'Inter',
                              height: 1.0,
                            ),
                          ),
                        ],
                      ),
                    ),
                    PopupMenuButton<_FilterPeriod>(
                      onSelected: (value) {
                        setState(() => _period = value);
                        _saveFilterPeriod(value);
                      },
                      itemBuilder: (context) => const [
                        PopupMenuItem(value: _FilterPeriod.today, child: Text('Сегодня')),
                        PopupMenuItem(value: _FilterPeriod.week, child: Text('Неделя')),
                        PopupMenuItem(value: _FilterPeriod.month, child: Text('Месяц')),
                        PopupMenuItem(value: _FilterPeriod.all, child: Text('Всё время')),
                      ],
                      offset: Offset(0, dp(context, 28)),
                      child: Container(
                        height: dp(context, 32),
                        padding: EdgeInsets.symmetric(horizontal: dp(context, 10)),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(dp(context, 5)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _periodLabel(_period),
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: filterFont,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Inter',
                                height: 1.0,
                              ),
                            ),
                            SizedBox(width: dp(context, 4)),
                            SvgPicture.asset(
                              'assets/arrow_drop_down.svg',
                              width: dp(context, 24),
                              height: dp(context, 24),
                              colorFilter: const ColorFilter.mode(Colors.white, BlendMode.srcIn),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );

        final list = CustomScrollView(
          slivers: [
            if (groups.isEmpty) ...[
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.only(top: dp(context, 24)),
                  child: Center(
                    child: Text(
                      'Нет записей за выбранный период',
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
                      ),
                    ),
                  ),
                ),
              ),
              SliverToBoxAdapter(child: SizedBox(height: dp(context, 24))),
            ] else ...[
              for (final g in groups) ...[
                // Заголовок даты (без “N записей” под каждой датой)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.only(right: side, top: dp(context, 4), bottom: dp(context, 4)),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        _formatDate(g.key),
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          color: const Color(0xFF325674),
                          fontSize: sp(context, 16),
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Inter',
                          height: 1.0,
                        ),
                      ),
                    ),
                  ),
                ),

                SliverList(
                  delegate: SliverChildBuilderDelegate(
                        (context, i) {
                      final r = g.value[i];
                      return Padding(
                        padding: EdgeInsets.fromLTRB(side, dp(context, 16), side, 0),
                        child: RecordListItem(
                          record: r,
                          onTap: () => _openEdit(context, r),
                        ),
                      );
                    },
                    childCount: g.value.length,
                  ),
                ),

                SliverToBoxAdapter(child: SizedBox(height: dp(context, 12))),
              ],
            ],
          ],
        );

        return ColoredBox(
          color: const Color(0xFFF0F4F8),
          child: Column(
            children: [
              // фиксированная шапка
              SizedBox(
                height: blueH + lightH,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    header,
                    // Карточка «последнее измерение»
                    Positioned(
                      left: side,
                      top: blueH - overlap,
                      child: SummaryCard(record: lastRecord),
                    ),
                  ],
                ),
              ),
              Expanded(child: list),
            ],
          ),
        );
      },
    );
  }

  List<MapEntry<DateTime, List<BloodPressureRecord>>> _groupByDate(List<BloodPressureRecord> records) {
    final grouped = <DateTime, List<BloodPressureRecord>>{};
    for (final r in records) {
      final d = DateTime(r.dateTime.year, r.dateTime.month, r.dateTime.day);
      grouped.putIfAbsent(d, () => []).add(r);
    }
    final keys = grouped.keys.toList()..sort((a, b) => b.compareTo(a));
    return [for (final k in keys) MapEntry(k, grouped[k]!)];
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    if (date == today) {
      return 'Сегодня, ${DateFormat('d MMMM', 'ru').format(date)}';
    }
    return DateFormat('d MMMM yyyy, EEEE', 'ru').format(date);
  }
}
