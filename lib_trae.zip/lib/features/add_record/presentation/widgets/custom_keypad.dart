import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';

class CustomKeypad extends StatelessWidget {
  final Function(String) onKeyPressed;
  final VoidCallback onDeletePressed;
  final List<String> enabledKeys;
  final double score;

  const CustomKeypad({
    super.key,
    required this.onKeyPressed,
    required this.onDeletePressed,
    required this.enabledKeys,
    required this.score,
  });

  @override
  Widget build(BuildContext context) {
    final keys = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
      ['', '0', 'delete'],
    ];

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Column(
        children: keys.map((row) {
          return Row(
            children: row.map((key) {
              if (key.isEmpty) return const Spacer();

              final bool isEnabled = key == 'delete' || enabledKeys.contains(key);

              return Padding(
                padding: const EdgeInsets.all(4.0),
                child: SizedBox(
                  width: AppUI.keypadButtonWidth * score,
                  height: AppUI.keypadButtonHeight * score,
                  child: InkWell(
                    onTap: isEnabled
                        ? () => key == 'delete' ? onDeletePressed() : onKeyPressed(key)
                        : null,
                    borderRadius: BorderRadius.circular(AppUI.fieldRadius),
                    child: AnimatedOpacity(
                      duration: const Duration(milliseconds: 200),
                      opacity: isEnabled ? 1.0 : 0.3,
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppUI.white,
                          borderRadius: BorderRadius.circular(AppUI.fieldRadius),
                          boxShadow: const [AppUI.shadow4x2],
                        ),
                        alignment: Alignment.center,
                        child: key == 'delete'
                            ? Icon(Icons.backspace_outlined, color: AppUI.buttonBlue, size: 18 * score)
                            : Text(key, style: TextStyle(color: AppUI.buttonBlue, fontSize: 18 * score, fontWeight: FontWeight.w400)),
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          );
        }).toList(),
      ),
    );
  }
}
