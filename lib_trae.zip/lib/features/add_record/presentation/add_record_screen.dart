import 'package:blood_pressure_diary/features/home/data/blood_pressure_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';
import 'bloc/add_record_bloc.dart';
import 'bloc/add_record_event.dart';
import 'bloc/add_record_state.dart';
import 'widgets/custom_keypad.dart';
import '../../../../core/theme/app_theme.dart';

class AddRecordScreen extends StatelessWidget {
  final BloodPressureRecord? record;
  const AddRecordScreen({super.key, this.record});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) {
        final bloc = GetIt.I<AddRecordBloc>();
        if (record != null) bloc.add(EditStarted(record!));
        return bloc;
      },
      child: const AddRecordView(),
    );
  }
}

class AddRecordView extends StatefulWidget {
  const AddRecordView({super.key});
  @override
  State<AddRecordView> createState() => _AddRecordViewState();
}

class _AddRecordViewState extends State<AddRecordView> {
  final TextEditingController _noteController = TextEditingController();
  final FocusNode _noteFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _noteFocusNode.addListener(() {
      if (_noteFocusNode.hasFocus) {
        context.read<AddRecordBloc>().add(const FieldChanged(InputField.none));
      }
    });
  }

  @override
  void dispose() {
    _noteController.dispose();
    _noteFocusNode.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final s = screenWidth / 360.0;
    final score = s.clamp(0.85, 1.25).toDouble();
    return BlocListener<AddRecordBloc, AddRecordState>(
      // СЛУШАЕМ ТУТ: Реагируем на флаг закрытия и смену полей
      listenWhen: (p, c) => p.activeField != c.activeField || p.shouldClose != c.shouldClose,
      listener: (context, state) {
        if (state.shouldClose) {
          Navigator.pop(context);
          return;
        }
        if (state.activeField == InputField.none) {
          _noteFocusNode.requestFocus();
        }
      },
      child: Scaffold(
        backgroundColor: AppUI.background,
        appBar: AppBar(
          backgroundColor: AppUI.headerBlue,
          elevation: 0,
          toolbarHeight: 128 * score,
          leading: IconButton(
            icon: Icon(Icons.close, color: AppUI.white),
            onPressed: () => Navigator.pop(context),
          ),
          title: Text("Новая запись", style: TextStyle(color: AppUI.white, fontSize: 24 * score, fontWeight: FontWeight.w600, fontFamily: 'Inter')),
        ),
        body: BlocBuilder<AddRecordBloc, AddRecordState>(
          builder: (context, state) {
            // Синхронизация текста
            if (_noteController.text != state.note) {
              _noteController.text = state.note;
              _noteController.selection = TextSelection.fromPosition(
                  TextPosition(offset: _noteController.text.length)
              );
            }

            return Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        SizedBox(height: 20 * score),
                        _buildPressureRow(state),
                        SizedBox(height: 16 * score),
                        _buildDateTimeRow(context, state),
                        SizedBox(height: 30 * score),
                        _buildNoteField(state), // ТОТ САМЫЙ МЕТОД
                        SizedBox(height: 16 * score),
                        _buildEmojiRow(context),
                      ],
                    ),
                  ),
                ),

                if (state.activeField != InputField.none)
                  CustomKeypad(
                    onKeyPressed: (v) => context.read<AddRecordBloc>().add(NumberPressed(v)),
                    onDeletePressed: () => context.read<AddRecordBloc>().add(BackspacePressed()),
                    enabledKeys: state.enabledKeys,
                    score: score,
                  ),

                _buildSaveButton(state),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildDateTimeRow(BuildContext context, AddRecordState state) {
    final dateText = DateFormat('d MMMM yyyy, EEEE', 'ru').format(state.selectedDateTime);
    final timeText = DateFormat('HH:mm').format(state.selectedDateTime);
    final screenWidth = MediaQuery.of(context).size.width;
    final s = screenWidth / 360.0;
    final score = s.clamp(0.85, 1.25).toDouble();
    final pad = 20.0 * score;
    final gap = 16.0 * score;
    final tileW = (screenWidth - 2 * pad - 2 * gap) / 3;
    final timeW = tileW;
    final dateW = 2 * tileW + gap;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: pad),
      child: Row(
        children: [
          SizedBox(
            width: timeW,
            height: AppUI.fieldHeight * score,
            child: OutlinedButton(
              onPressed: () async {
                final now = state.selectedDateTime;
                final picked = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay(hour: now.hour, minute: now.minute),
                  helpText: 'Выберите время',
                );
                if (picked != null) {
                  if (!context.mounted) return;
                  final merged = DateTime(
                    now.year, now.month, now.day,
                    picked.hour, picked.minute,
                  );
                  context.read<AddRecordBloc>().add(DateTimeSet(merged));
                }
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: AppUI.buttonBlue,
                side: BorderSide(color: Colors.grey.withValues(alpha: 0.15)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppUI.fieldRadius)),
                padding: EdgeInsets.symmetric(vertical: 12 * score, horizontal: 14 * score),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SvgPicture.asset('assets/clock.svg', width: 18 * score, height: 18 * score, colorFilter: ColorFilter.mode(AppUI.buttonBlue, BlendMode.srcIn)),
                  SizedBox(width: 8 * score),
                  Text(timeText, style: TextStyle(color: AppUI.buttonBlue, fontSize: 18 * score, fontWeight: FontWeight.w400, fontFamily: 'Inter')),
                ],
              ),
            ),
          ),
          SizedBox(width: gap),
          SizedBox(
            width: dateW,
            height: AppUI.fieldHeight * score,
            child: OutlinedButton(
              onPressed: () async {
                final now = state.selectedDateTime;
                final picked = await showDatePicker(
                  context: context,
                  initialDate: now,
                  firstDate: DateTime(now.year - 1),
                  lastDate: DateTime(now.year + 1),
                  helpText: 'Выберите дату',
                );
                if (picked != null) {
                  if (!context.mounted) return;
                  final merged = DateTime(
                    picked.year, picked.month, picked.day,
                    now.hour, now.minute,
                  );
                  context.read<AddRecordBloc>().add(DateTimeSet(merged));
                }
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: AppUI.buttonBlue,
                side: BorderSide(color: Colors.grey.withValues(alpha: 0.15)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppUI.fieldRadius)),
                padding: EdgeInsets.symmetric(vertical: 12 * score, horizontal: 14 * score),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SvgPicture.asset('assets/calendar.svg', width: 18 * score, height: 18 * score, colorFilter: ColorFilter.mode(AppUI.buttonBlue, BlendMode.srcIn)),
                  SizedBox(width: 8 * score),
                  Flexible(child: Text(dateText, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppUI.buttonBlue, fontSize: 18 * score, fontWeight: FontWeight.w400, fontFamily: 'Inter'))),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ВОТ ЭТОТ МЕТОД Я ПРОПУСТИЛ В ПРОШЛЫЙ РАЗ:
  Widget _buildNoteField(AddRecordState state) {
    final screenWidth = MediaQuery.of(context).size.width;
    final s = screenWidth / 360.0;
    final score = s.clamp(0.85, 1.25).toDouble();
    final pad = 20.0 * score;
    final width = screenWidth - 2 * pad;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: pad),
      child: Container(
        width: width,
        height: AppUI.noteHeight * score,
        decoration: BoxDecoration(
          color: AppUI.white,
          borderRadius: BorderRadius.circular(AppUI.fieldRadius),
          boxShadow: const [AppUI.shadow4x2],
        ),
        alignment: Alignment.centerLeft,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 14 * score, vertical: 12 * score),
          child: TextField(
            controller: _noteController,
            focusNode: _noteFocusNode,
            expands: false,
            minLines: 1,
            maxLines: 1,
            textAlignVertical: TextAlignVertical.top,
            onChanged: (v) => context.read<AddRecordBloc>().add(NoteChanged(v)),
            style: TextStyle(color: AppUI.textPrimary, fontSize: 16 * score, fontFamily: 'Inter'),
            decoration: InputDecoration(
              hintText: "Комментарий",
              hintStyle: TextStyle(color: AppUI.textLight, fontSize: 14 * score, fontFamily: 'Inter', fontWeight: FontWeight.w700),
              border: InputBorder.none,
              isCollapsed: true,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPressureRow(AddRecordState state) {
    final screenWidth = MediaQuery.of(context).size.width;
    final s = screenWidth / 360.0;
    final score = s.clamp(0.85, 1.25).toDouble();
    final pad = 20.0 * score;
    final gap = 16.0 * score;
    final tileW = (screenWidth - 2 * pad - 2 * gap) / 3;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: pad),
      child: Row(
        children: [
          _buildBox("Сист.", state.systolic, state.activeField == InputField.systolic, tileW, score),
          SizedBox(
            width: gap,
            child: Center(child: Text("/", style: TextStyle(color: AppUI.textLight, fontSize: 18 * score, fontFamily: 'Inter'))),
          ),
          _buildBox("Диаст.", state.diastolic, state.activeField == InputField.diastolic, tileW, score),
          SizedBox(width: gap),
          _buildBox("Пульс", state.pulse, state.activeField == InputField.pulse, tileW, score),
        ],
      ),
    );
  }

  Widget _buildBox(String label, String value, bool active, double width, double score) {
    return SizedBox(
      width: width,
      height: AppUI.fieldHeight * score,
      child: GestureDetector(
        onTap: () {
          _noteFocusNode.unfocus();
          context.read<AddRecordBloc>().add(FieldChanged(
              label == "Сист." ? InputField.systolic : (label == "Диаст." ? InputField.diastolic : InputField.pulse)
          ));
        },
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 8 * score),
          decoration: BoxDecoration(
            color: AppUI.white,
            borderRadius: BorderRadius.circular(AppUI.fieldRadius),
            boxShadow: const [AppUI.shadow4x2],
            border: active ? Border.all(color: AppUI.headerBlue, width: 2) : null,
          ),
          child: Column(
            children: [
              Text(label, style: TextStyle(color: AppUI.textLight, fontSize: 16 * score, fontWeight: FontWeight.w400)),
              Text(value.isEmpty ? "--" : value, style: TextStyle(color: AppUI.textPrimary, fontSize: 18 * score, fontWeight: FontWeight.w400)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmojiRow(BuildContext context) {
    final emojis = [
      {'key': '❤️', 'file': 'heart.svg'},
      {'key': '💊', 'file': 'pill.svg'},
      {'key': '😁', 'file': 'grinning.svg'},
      {'key': '🙂', 'file': 'slightly_smiling_face.svg'},
      {'key': '😒', 'file': 'unamused.svg'},
      {'key': '🤕', 'file': 'face_with_head_bandage.svg'},
    ];
    final screenWidth = MediaQuery.of(context).size.width;
    final s = screenWidth / 360.0;
    final score = s.clamp(0.85, 1.25).toDouble();
    final pad = 20.0 * score;
    final item = 32 * score;
    final step = 16 * score;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: pad),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: List.generate(emojis.length, (i) => Padding(
          padding: EdgeInsets.only(right: i == emojis.length - 1 ? 0 : step),
          child: SizedBox(
            width: item,
            height: item,
            child: InkWell(
              borderRadius: BorderRadius.circular(item / 2),
              onTap: () => context.read<AddRecordBloc>().add(EmojiAppended(emojis[i]['key']!)),
              child: Center(
                child: SvgPicture.asset('assets/${emojis[i]['file']}', width: 26 * score, height: 26 * score),
              ),
            ),
          ),
        )),
      ),
    );
  }

  Widget _buildSaveButton(AddRecordState state) {
    final screenWidth = MediaQuery.of(context).size.width;
    final s = screenWidth / 360.0;
    final score = s.clamp(0.85, 1.25).toDouble();
    final hPad = 20.0 * score;
    final gap = 16.0 * score;
    final tileW = (screenWidth - 2 * hPad - 2 * gap) / 3;
    final saveW = 2 * tileW + gap;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: hPad),
      child: Align(
        alignment: Alignment.centerRight,
        child: SizedBox(
          width: saveW,
          height: AppUI.fieldHeight * score,
          child: ElevatedButton(
            onPressed: state.isValid ? () => context.read<AddRecordBloc>().add(SaveSubmitted()) : null,
            child: const Text("Сохранить"),
          ),
        ),
      ),
    );
  }
}
