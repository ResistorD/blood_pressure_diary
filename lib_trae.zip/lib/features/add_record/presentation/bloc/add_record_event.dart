import 'package:equatable/equatable.dart';
import 'add_record_state.dart';
// Импортируем модель, чтобы событие EditStarted знало о BloodPressureRecord
import '../../../home/data/blood_pressure_model.dart';

abstract class AddRecordEvent extends Equatable {
  const AddRecordEvent();
  @override
  List<Object?> get props => [];
}

// СОБЫТИЕ ДЛЯ РЕДАКТИРОВАНИЯ
class EditStarted extends AddRecordEvent {
  final BloodPressureRecord record;
  const EditStarted(this.record);

  @override
  List<Object?> get props => [record];
}

class NumberPressed extends AddRecordEvent {
  final String number;
  const NumberPressed(this.number);
  @override
  List<Object?> get props => [number];
}

class BackspacePressed extends AddRecordEvent {}

class FieldChanged extends AddRecordEvent {
  final InputField field;
  const FieldChanged(this.field);
  @override
  List<Object?> get props => [field];
}

// СОБЫТИЕ ДЛЯ ЗАМЕТОК
class NoteChanged extends AddRecordEvent {
  final String note;
  const NoteChanged(this.note);

  @override
  List<Object?> get props => [note];
}

class EmotionChanged extends AddRecordEvent {
  final String emotion;
  const EmotionChanged(this.emotion);
  @override
  List<Object?> get props => [emotion];
}

class EmojiAppended extends AddRecordEvent {
  final String emoji;
  const EmojiAppended(this.emoji);

  @override
  List<Object?> get props => [emoji];
}

class SaveSubmitted extends AddRecordEvent {}

class DateTimeSet extends AddRecordEvent {
  final DateTime value;
  const DateTimeSet(this.value);
  @override
  List<Object?> get props => [value];
}
