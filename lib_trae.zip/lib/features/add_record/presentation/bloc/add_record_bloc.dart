import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:isar/isar.dart';
import '../../../../core/utils/validation_utils.dart';
import '../../../../core/repositories/pressure_repository.dart';
import '../../../home/data/blood_pressure_model.dart';
import 'add_record_event.dart';
import 'add_record_state.dart';

class AddRecordBloc extends Bloc<AddRecordEvent, AddRecordState> {
  final PressureRepository _repository;
  int? _editingId;

  AddRecordBloc(this._repository) : super(AddRecordState()) {
    on<EditStarted>(_onEditStarted);
    on<NumberPressed>(_onNumberPressed);
    on<BackspacePressed>(_onBackspacePressed);
    on<FieldChanged>(_onFieldChanged);
    on<NoteChanged>((event, emit) => emit(state.copyWith(note: event.note)));
    on<EmojiAppended>(_onEmojiAppended);
    on<SaveSubmitted>(_onSaveSubmitted);
    on<DateTimeSet>((event, emit) => emit(state.copyWith(selectedDateTime: event.value)));
  }

  void _onEditStarted(EditStarted event, Emitter<AddRecordState> emit) {
    _editingId = event.record.id;
    final newState = state.copyWith(
      systolic: event.record.systolic.toString(),
      diastolic: event.record.diastolic.toString(),
      pulse: event.record.pulse.toString(),
      note: event.record.note ?? '',
      selectedDateTime: event.record.dateTime,
    );
    emit(newState);
    _updateEnabledKeys(emit, newState);
  }

  void _onNumberPressed(NumberPressed event, Emitter<AddRecordState> emit) {
    final current = _getVal(state.activeField);
    final sysVal = int.tryParse(state.systolic);

    if (ValidationUtils.isDigitAllowed(
      currentText: current,
      digit: event.number,
      fieldType: _getTypeString(state.activeField),
      systolicValue: state.activeField == InputField.diastolic ? sysVal : null,
    )) {
      final newValue = current + event.number;
      final newState = _updateValueInState(state, newValue);

      if (newValue.length == 3) {
        _autoNextField(emit, newState);
      } else {
        emit(newState);
        _updateEnabledKeys(emit, newState);
      }
    }
  }

  void _onBackspacePressed(BackspacePressed event, Emitter<AddRecordState> emit) {
    final current = _getVal(state.activeField);
    if (current.isEmpty) {
      _autoPrevField(emit);
    } else {
      final newValue = current.substring(0, current.length - 1);
      final newState = _updateValueInState(state, newValue);
      emit(newState);
      _updateEnabledKeys(emit, newState);
    }
  }

  void _onFieldChanged(FieldChanged event, Emitter<AddRecordState> emit) {
    final newState = state.copyWith(activeField: event.field);
    emit(newState);
    _updateEnabledKeys(emit, newState);
  }

  void _onEmojiAppended(EmojiAppended event, Emitter<AddRecordState> emit) {
    emit(state.copyWith(note: state.note + event.emoji));
  }

  void _updateEnabledKeys(Emitter<AddRecordState> emit, AddRecordState currentState) {
    if (currentState.activeField == InputField.none) return;
    final List<String> available = [];
    final sysVal = int.tryParse(currentState.systolic);
    final currentText = _getVal(currentState.activeField);
    final type = _getTypeString(currentState.activeField);

    for (int i = 0; i <= 9; i++) {
      if (ValidationUtils.isDigitAllowed(
        currentText: currentText,
        digit: i.toString(),
        fieldType: type,
        systolicValue: type == 'DIA' ? sysVal : null,
      )) {
        available.add(i.toString());
      }
    }
    emit(currentState.copyWith(enabledKeys: available));
  }

  String _getVal(InputField field) {
    if (field == InputField.systolic) return state.systolic;
    if (field == InputField.diastolic) return state.diastolic;
    return state.pulse;
  }

  String _getTypeString(InputField field) {
    if (field == InputField.systolic) return 'SYS';
    if (field == InputField.diastolic) return 'DIA';
    return 'PUL';
  }

  AddRecordState _updateValueInState(AddRecordState s, String val) {
    if (s.activeField == InputField.systolic) return s.copyWith(systolic: val);
    if (s.activeField == InputField.diastolic) return s.copyWith(diastolic: val);
    return s.copyWith(pulse: val);
  }

  void _autoNextField(Emitter<AddRecordState> emit, AddRecordState s) {
    InputField next = s.activeField;
    if (s.activeField == InputField.systolic) {
      next = InputField.diastolic;
    } else if (s.activeField == InputField.diastolic) {
      next = InputField.pulse;
    } else if (s.activeField == InputField.pulse) {
      next = InputField.none;
    }

    final ns = s.copyWith(activeField: next);
    emit(ns);
    _updateEnabledKeys(emit, ns);
  }

  void _autoPrevField(Emitter<AddRecordState> emit) {
    InputField? prev;
    if (state.activeField == InputField.diastolic) {
      prev = InputField.systolic;
    }
    if (state.activeField == InputField.pulse) {
      prev = InputField.diastolic;
    }
    if (prev != null) {
      final ns = state.copyWith(activeField: prev);
      emit(ns);
      _updateEnabledKeys(emit, ns);
    }
  }

  Future<void> _onSaveSubmitted(SaveSubmitted event, Emitter<AddRecordState> emit) async {
    if (state.systolic.isEmpty || state.diastolic.isEmpty || state.pulse.isEmpty) {
      return;
    }
    
    final sys = int.tryParse(state.systolic);
    final dia = int.tryParse(state.diastolic);
    final pul = int.tryParse(state.pulse);
    
    if (sys == null || dia == null || pul == null || sys == 0 || dia == 0 || pul == 0) {
       return;
    }

    final record = BloodPressureRecord()
      ..id = _editingId ?? Isar.autoIncrement
      ..systolic = sys
      ..diastolic = dia
      ..pulse = pul
      ..note = state.note
      ..dateTime = state.selectedDateTime;
    await _repository.addRecord(record);
    emit(state.copyWith(shouldClose: true));
  }
}
