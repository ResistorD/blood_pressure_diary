import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:blood_pressure_diary/core/services/export_service.dart';
import 'package:blood_pressure_diary/core/theme/app_theme.dart';
import 'package:blood_pressure_diary/core/theme/scale.dart';
import 'package:blood_pressure_diary/features/settings/presentation/bloc/settings_cubit.dart';
import 'package:blood_pressure_diary/features/settings/presentation/bloc/settings_state.dart';
import 'package:blood_pressure_diary/l10n/generated/app_localizations.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    final isDark = Theme.of(context).brightness == Brightness.dark;

    final colors = context.appColors;
    final space = context.appSpace;
    final radii = context.appRadii;
    final shadows = context.appShadow;
    final text = context.appText;

    final safeTop = MediaQuery.paddingOf(context).top;

    // Layout tokens (Figma-like)
    final headerH = dp(context, space.s128);
    final side = dp(context, space.s20);

    final cardW = dp(context, space.w320);
    final innerW = cardW - dp(context, space.s24); // 296
    final cardR = dp(context, radii.r10);

    final fieldH = dp(context, space.s48);

    // Heights without raw numbers
    final h47 = dp(context, space.s46 + space.s1);
    final h92 = dp(context, space.s80 + space.s12);
    final h180 = dp(context, space.s160 + space.s20);

    // Inner reminders box height ~ 97
    final h97 = dp(context, space.s96 + space.s1);

    // Time boxes are slightly smaller than 48 in макете
    final h43 = dp(context, space.s40 + space.s2 + space.s1);
    final h44 = dp(context, space.s40 + space.s4);

    // Text
    final titleStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs24),
      fontWeight: text.w600,
      color: isDark ? colors.textPrimary : colors.textOnBrand,
      height: 1.0,
    );

    final cardTitleStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs20),
      fontWeight: text.w600,
      color: colors.textPrimary,
      height: 1.0,
    );

    final labelStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs12),
      fontWeight: text.w400,
      color: colors.textPrimary,
      height: 1.0,
    );

    final itemStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs20),
      fontWeight: text.w500,
      color: colors.textPrimary,
      height: 1.0,
    );

    final addTimeStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs16),
      fontWeight: text.w600,
      color: colors.textPrimary,
      height: 1.0,
    );

    final versionStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs12),
      fontWeight: text.w400,
      color: colors.textPrimary,
      height: 1.0,
    );

    // Colors from theme/palette (no hardcoded Color)
    final headerBg = isDark ? AppPalette.dark800 : AppPalette.blue700;

    final cardBg = colors.surface;
    final fieldBg = isDark ? colors.surfaceAlt : colors.background;

    // В макете внутренний блок напоминаний: border, а фон — как поле (light) / как тёмный слой (dark)
    final remindersInnerBg = isDark ? AppPalette.dark800 : colors.background;
    final remindersInnerBorder = isDark ? AppPalette.dark800 : colors.background;

    // Переключатель (Figma-like)
    final toggleTrackOn = isDark ? AppPalette.dark800 : AppPalette.blue900;
    final toggleTrackOff = isDark ? AppPalette.dark800 : AppPalette.grey200;
    final toggleKnobOn = isDark ? AppPalette.dark400 : colors.surface;
    final toggleKnobOff = isDark ? AppPalette.dark400 : colors.surface;

    // Overlay during export (no withOpacity)
    final exportOverlay = colors.textPrimary.withValues(alpha: 0.10);

    return BlocListener<SettingsCubit, SettingsState>(
      listener: (context, state) {
        final msg = state.errorMessage;
        if (msg == null) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(msg),
            backgroundColor: colors.danger,
          ),
        );
      },
      child: BlocBuilder<SettingsCubit, SettingsState>(
        builder: (context, state) {
          final settings = state.settings;

          // Макет показывает 2 времени. Берём первые два из списка, иначе дефолты.
          String morning = '08:00';
          String evening = '20:00';
          if (settings.reminders.isNotEmpty) {
            morning = settings.reminders.first;
            if (settings.reminders.length > 1) evening = settings.reminders[1];
          }

          final notificationsEnabled = settings.notificationsEnabled;

          Future<void> pickTimeAndAdd() async {
            final picked = await showTimePicker(
              context: context,
              initialTime: TimeOfDay.now(),
            );
            if (picked != null && context.mounted) {
              context.read<SettingsCubit>().addReminder(picked);
            }
          }

          Widget card({
            required double height,
            required Widget child,
          }) {
            return SizedBox(
              width: cardW,
              height: height,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(cardR),
                  boxShadow: [shadows.card],
                ),
                child: child,
              ),
            );
          }

          Widget timeRow({
            required String leftLabel,
            required String value,
            required double valueHeight,
            required VoidCallback onTap,
          }) {
            return SizedBox(
              height: valueHeight,
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(left: dp(context, space.s12)),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(leftLabel, style: itemStyle),
                      ),
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: notificationsEnabled ? onTap : null,
                    child: Container(
                      width: dp(context, space.s120 + space.s16 + space.s1), // 137
                      height: valueHeight,
                      decoration: BoxDecoration(
                        color: fieldBg,
                        borderRadius: BorderRadius.circular(cardR),
                      ),
                      padding: EdgeInsets.symmetric(horizontal: dp(context, space.s12)),
                      alignment: Alignment.centerRight,
                      child: Text(value, style: itemStyle),
                    ),
                  ),
                ],
              ),
            );
          }

          Widget remindersCard() {
            return card(
              height: h180,
              child: Padding(
                padding: EdgeInsets.all(dp(context, space.s12)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(child: Text(l10n.reminders, style: cardTitleStyle)),
                        _FigmaSwitch(
                          value: notificationsEnabled,
                          onChanged: (v) => context.read<SettingsCubit>().toggleNotifications(v),
                          trackOn: toggleTrackOn,
                          trackOff: toggleTrackOff,
                          knobOn: toggleKnobOn,
                          knobOff: toggleKnobOff,
                          space: space,
                        ),
                      ],
                    ),
                    SizedBox(height: dp(context, space.s10)),
                    Opacity(
                      opacity: notificationsEnabled ? 1.0 : 0.55,
                      child: Container(
                        width: innerW,
                        height: h97,
                        decoration: BoxDecoration(
                          color: remindersInnerBg,
                          borderRadius: BorderRadius.circular(cardR),
                          border: Border.all(
                            width: dp(context, space.s1),
                            color: remindersInnerBorder,
                          ),
                        ),
                        padding: EdgeInsets.all(dp(context, space.s8)),
                        child: Column(
                          children: [
                            timeRow(
                              leftLabel: 'Утро',
                              value: morning,
                              valueHeight: h43,
                              onTap: pickTimeAndAdd,
                            ),
                            SizedBox(height: dp(context, space.s10)),
                            timeRow(
                              leftLabel: 'Вечер',
                              value: evening,
                              valueHeight: h44,
                              onTap: pickTimeAndAdd,
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Spacer(),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Opacity(
                        opacity: notificationsEnabled ? 1.0 : 0.55,
                        child: GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: notificationsEnabled ? pickTimeAndAdd : null,
                          child: Padding(
                            padding: EdgeInsets.only(right: dp(context, space.s6)),
                            child: Text('+${l10n.addReminder.toUpperCase()}', style: addTimeStyle),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          Widget themeCard() {
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () async {
                final chosen = await _showThemeSheet(context, l10n, settings.themeMode);
                if (chosen != null && context.mounted) {
                  context.read<SettingsCubit>().setThemeMode(chosen);
                }
              },
              child: card(
                height: h92,
                child: Padding(
                  padding: EdgeInsets.all(dp(context, space.s12)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(l10n.theme, style: labelStyle),
                      SizedBox(height: dp(context, space.s6)),
                      Container(
                        width: innerW,
                        height: fieldH,
                        decoration: BoxDecoration(
                          color: fieldBg,
                          borderRadius: BorderRadius.circular(cardR),
                        ),
                        padding: EdgeInsets.symmetric(horizontal: dp(context, space.s12)),
                        child: Row(
                          children: [
                            Expanded(child: Text(_themeTitle(settings.themeMode, l10n), style: itemStyle)),
                            Icon(
                              Icons.keyboard_arrow_down,
                              color: colors.textPrimary,
                              size: dp(context, space.s20),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }

          Widget actionButton({
            required String title,
            required VoidCallback onTap,
          }) {
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: onTap,
              child: SizedBox(
                width: cardW,
                height: h47,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: cardBg,
                    borderRadius: BorderRadius.circular(cardR),
                    boxShadow: [shadows.card],
                  ),
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: dp(context, space.s16)),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(title, style: itemStyle),
                    ),
                  ),
                ),
              ),
            );
          }

          return Scaffold(
            backgroundColor: colors.background,
            body: Stack(
              children: [
                // Header bg
                Positioned(
                  left: 0,
                  right: 0,
                  top: 0,
                  height: headerH,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: headerBg,
                      boxShadow: [shadows.strong],
                    ),
                  ),
                ),

                // Title
                Positioned(
                  left: side,
                  top: safeTop + dp(context, space.s20),
                  child: Text(l10n.settings, style: titleStyle),
                ),

                // Content
                Positioned.fill(
                  top: safeTop + headerH - dp(context, space.s40),
                  child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                      left: side,
                      right: side,
                      top: dp(context, space.s20),
                      bottom: dp(context, space.s96),
                    ),
                    child: Column(
                      children: [
                        remindersCard(),
                        SizedBox(height: dp(context, space.s20)),
                        themeCard(),
                        SizedBox(height: dp(context, space.s20)),

                        actionButton(
                          title: l10n.clearData,
                          onTap: () => _showClearDataDialog(context, l10n),
                        ),
                        SizedBox(height: dp(context, space.s12)),

                        actionButton(
                          title: '${l10n.export} (CSV)',
                          onTap: state.isExporting ? () {} : () => _showExportBottomSheet(context, l10n),
                        ),
                        SizedBox(height: dp(context, space.s12)),

                        actionButton(
                          title: l10n.contactSupport,
                          onTap: () => context.read<SettingsCubit>().contactSupport(),
                        ),
                        SizedBox(height: dp(context, space.s12)),

                        actionButton(
                          title: l10n.rateApp,
                          onTap: () => context.read<SettingsCubit>().rateApp(),
                        ),

                        SizedBox(height: dp(context, space.s20)),
                        Center(child: Text(l10n.version('1.0'), style: versionStyle)),
                      ],
                    ),
                  ),
                ),

                if (state.isExporting)
                  Positioned.fill(
                    child: ColoredBox(
                      color: exportOverlay,
                      child: const Center(child: CircularProgressIndicator()),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  String _themeTitle(AppThemeMode mode, AppLocalizations l10n) {
    switch (mode) {
      case AppThemeMode.light:
        return l10n.light;
      case AppThemeMode.dark:
        return l10n.dark;
      case AppThemeMode.system:
        return l10n.system;
    }
  }

  Future<AppThemeMode?> _showThemeSheet(BuildContext context, AppLocalizations l10n, AppThemeMode current) {
    return showModalBottomSheet<AppThemeMode>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        Widget item(AppThemeMode mode, String title) {
          final selected = mode == current;
          return ListTile(
            title: Text(title),
            trailing: selected ? const Icon(Icons.check) : null,
            onTap: () => Navigator.pop(ctx, mode),
          );
        }

        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              item(AppThemeMode.system, l10n.system),
              item(AppThemeMode.light, l10n.light),
              item(AppThemeMode.dark, l10n.dark),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  void _showExportBottomSheet(BuildContext context, AppLocalizations l10n) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                l10n.export,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.picture_as_pdf_outlined),
              title: Text(l10n.exportPDF),
              onTap: () {
                Navigator.pop(context);
                context.read<SettingsCubit>().exportData(ExportFormat.pdf);
              },
            ),
            ListTile(
              leading: const Icon(Icons.description_outlined),
              title: Text(l10n.exportCSV),
              onTap: () {
                Navigator.pop(context);
                context.read<SettingsCubit>().exportData(ExportFormat.csv);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _showClearDataDialog(BuildContext context, AppLocalizations l10n) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(l10n.clearData),
        content: Text(l10n.clearDataConfirm),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(l10n.no),
          ),
          TextButton(
            onPressed: () {
              context.read<SettingsCubit>().clearAllData();
              Navigator.pop(ctx);
            },
            child: Text(l10n.yes),
          ),
        ],
      ),
    );
  }
}

class _FigmaSwitch extends StatelessWidget {
  final bool value;
  final ValueChanged<bool> onChanged;

  final Color trackOn;
  final Color trackOff;
  final Color knobOn;
  final Color knobOff;

  final AppSpacing space;

  const _FigmaSwitch({
    required this.value,
    required this.onChanged,
    required this.trackOn,
    required this.trackOff,
    required this.knobOn,
    required this.knobOff,
    required this.space,
  });

  @override
  Widget build(BuildContext context) {
    final trackW = dp(context, space.s40);
    final trackH = dp(context, space.s24);
    final knob = dp(context, space.s20);
    final pad = dp(context, space.s2);

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => onChanged(!value),
      child: Container(
        width: trackW,
        height: trackH,
        decoration: BoxDecoration(
          color: value ? trackOn : trackOff,
          borderRadius: BorderRadius.circular(trackH / 2),
        ),
        padding: EdgeInsets.all(pad),
        child: Align(
          alignment: value ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            width: knob,
            height: knob,
            decoration: BoxDecoration(
              color: value ? knobOn : knobOff,
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }
}
