import 'package:equatable/equatable.dart';
import 'package:blood_pressure_diary/core/database/models/user_profile.dart';

abstract class ProfileState extends Equatable {
  const ProfileState();

  @override
  List<Object?> get props => [];
}

class ProfileInitial extends ProfileState {}

class ProfileLoading extends ProfileState {}

class ProfileLoaded extends ProfileState {
  final UserProfile profile;

  const ProfileLoaded(this.profile);

  @override
  List<Object?> get props => [
    profile.name,
    profile.age,
    profile.gender,
    profile.weight,
    profile.targetSystolic,
    profile.targetDiastolic,

    // ✅ ВАЖНО: чтобы UI обновлялся при входе/выходе
    profile.accountLinked,
    profile.accountEmail,
    profile.accountProvider,
  ];
}

class ProfileError extends ProfileState {
  final String message;

  const ProfileError(this.message);

  @override
  List<Object?> get props => [message];
}
