import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/theme/scale.dart';
import '../../data/blood_pressure_model.dart';

class SummaryCard extends StatelessWidget {
  final BloodPressureRecord? record;

  const SummaryCard({super.key, this.record});

  String _hhmm(DateTime t) => DateFormat('HH:mm').format(t);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final colors = context.appColors;
    final space = context.appSpace;
    final radii = context.appRadii;
    final shadow = context.appShadow;
    final text = context.appText;

    final width = MediaQuery.sizeOf(context).width - dp(context, space.s20) * 2;
    final height = dp(context, space.s114); // по JSON: 114
    final r = dp(context, radii.r10);

    // ✅ JSON: summary card bg = rgb(45,45,45)
    final bg = isDark ? AppPalette.dark900 : AppPalette.blue600;

    // ✅ JSON: текст на dark — rgb(204,204,204)
    final mainText = isDark ? AppPalette.dark400 : colors.textOnBrand;

    // ✅ JSON: галочка в dark ближе к 116,116,116
    final checkColor = isDark ? AppPalette.dark600 : AppPalette.blue500;

    final checkSize = dp(context, space.s40);

    final pressureStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs30),
      fontWeight: text.w600,
      color: mainText,
      height: 1.0,
    );

    final pulseStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs22),
      fontWeight: text.w600,
      color: mainText,
      height: 1.0,
    );

    final timeStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs22),
      fontWeight: text.w600,
      color: mainText,
      height: 1.0,
    );

    final clockColor = isDark ? AppPalette.dark600 : colors.textOnBrand;

    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(r),
        boxShadow: [shadow.card],
      ),
      // ✅ FIX: меньше вертикальные отступы (высота 114 должна “дышать”, но без overflow)
      padding: EdgeInsets.fromLTRB(
        dp(context, space.s16),
        dp(context, space.s8),
        dp(context, space.s16),
        dp(context, space.s8),
      ),
      child: (record == null)
          ? Center(
        child: Text(
          'Нет данных',
          style: TextStyle(
            fontFamily: text.family,
            fontSize: sp(context, text.fs16),
            fontWeight: text.w500,
            color: mainText,
            height: 1.0,
          ),
        ),
      )
          : Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Text(
                  '${record!.systolic}/${record!.diastolic}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: pressureStyle,
                ),
              ),
              SizedBox(width: dp(context, space.s6)),
              SizedBox(
                width: checkSize,
                height: checkSize,
                child: Center(
                  child: SvgPicture.asset(
                    'assets/check.svg',
                    width: checkSize,
                    height: checkSize,
                    colorFilter: ColorFilter.mode(checkColor, BlendMode.srcIn),
                  ),
                ),
              ),
            ],
          ),
          // ✅ FIX: было 4 → 2
          SizedBox(height: dp(context, space.s2)),
          Row(
            children: [
              Text('${record!.pulse}', style: pulseStyle),
              SizedBox(width: dp(context, space.s6)),
              Text('уд/мин', style: pulseStyle),
            ],
          ),
          // ✅ FIX: было 8 → 6
          SizedBox(height: dp(context, space.s6)),
          Row(
            children: [
              SvgPicture.asset(
                'assets/clock.svg',
                width: dp(context, space.s20),
                height: dp(context, space.s20),
                colorFilter: ColorFilter.mode(clockColor, BlendMode.srcIn),
              ),
              SizedBox(width: dp(context, space.s6)),
              Text(_hhmm(record!.dateTime), style: timeStyle),
            ],
          ),
        ],
      ),
    );
  }
}
