import 'package:flutter/material.dart';

/// Единственный источник правды для UI:
/// - цвета (light/dark)
/// - размеры (spacing, icon sizes, базовые компоненты)
/// - радиусы
/// - тени
/// - типографика
///
/// Правило проекта: в UI-файлах — никаких хардкодов.
/// Всё берётся либо из ThemeExtension (context.appColors / appSpace / appRadii / appShadow / appText),
/// либо (временно для старого кода) из AppUI.
///
/// ВАЖНО:
/// - Тему делаем “один раз по всем JSON”.
/// - Дальше доводим экраны по очереди, НЕ возвращаясь к app_theme.dart.

@immutable
class _C {
  static const Color black = Color(0xFF000000);
  static const Color white = Color(0xFFFFFFFF);
}

// -----------------------------------------------------------------------------
// Raw palette (из всех JSON в пакете)

class AppPalette {
  // Blues
  static const Color blue900 = Color(0xFF2E5D85); // rgb(46,93,133)
  static const Color blue700 = Color(0xFF4D83AC); // rgb(77,131,172)
  static const Color blue600 = Color(0xFF3973A2); // rgb(57,115,162)
  static const Color blue500 = Color(0xFF6B9DC0); // rgb(107,157,192)
  static const Color blue300 = Color(0xFFBFD4E7); // rgb(191,212,231)

  // Greys (light)
  static const Color grey050 = Color(0xFFF9F8FA); // rgb(249,248,250)
  static const Color grey100 = Color(0xFFF5F5F5); // rgb(245,245,245)
  static const Color grey200 = Color(0xFFF0F4F8); // rgb(240,244,248)
  static const Color grey400 = Color(0xFFD9D9D9); // rgb(217,217,217)
  static const Color grey500 = Color(0xFFA0AEC0); // rgb(160,174,192)
  static const Color grey600 = Color(0xFF808080); // rgb(128,128,128)

  // Greys (dark)
  static const Color dark900 = Color(0xFF2D2D2D); // rgb(45,45,45)
  static const Color dark800 = Color(0xFF3C3C3C); // rgb(60,60,60)
  static const Color dark700 = Color(0xFF4C4C4C); // rgb(76,76,76)
  static const Color dark805 = Color(0xFF3D3D3D); // rgb(61,61,61) ✅ для linear кольца
  static const Color dark400 = Color(0xFFCCCCCC); // rgb(204,204,204)
  static const Color dark350 = Color(0xFFC6C6C6); // rgb(198,198,198)
  static const Color dark600 = Color(0xFF747474); // rgb(116,116,116)

  // Accents
  static const Color green = Color(0xFF3DBE65); // rgb(61,190,101)
  static const Color red = Color(0xFFDA3F3F); // rgb(218,63,63)
  static const Color blueAccent = Color(0xFF5A8EF6); // rgb(90,142,246)
  static const Color amber = Color(0xFFEB8F00); // rgb(235,143,0)

  // Error-ish variants present in some JSON
  static const Color red600 = Color(0xFFCC3333);
  static const Color redM3 = Color(0xFFF44336);
  static const Color redSoft = Color(0xFFFF8A80);
  static const Color redDark = Color(0xFFC62828);
  static const Color redWarm = Color(0xFFED7770);
  static const Color yellow = Color(0xFFFDD835);

  // Browns (встречаются в профиле)
  static const Color brown900 = Color(0xFF422B0D);
  static const Color brown700 = Color(0xFF896024);

  // Shadows
  static const Color shadow10 = Color(0x1A000000); // rgba(0,0,0,0.1)
  static const Color shadow25 = Color(0x40000000); // rgba(0,0,0,0.25)
}

// -----------------------------------------------------------------------------
// Semantic colors (то, чем реально должен пользоваться UI)

@immutable
class AppColors extends ThemeExtension<AppColors> {
  // Surfaces
  final Color background; // экран
  final Color surface; // карточки/поля
  final Color surfaceAlt; // вторичный фон/подложки

  // Brand
  final Color brand; // основной бренд (кнопки/акценты)
  final Color brandStrong; // более тёмный бренд (иконки/текст)
  final Color brandSoft; // мягкий бренд (чипы/подложки)

  // Text
  final Color textPrimary;
  final Color textSecondary;
  final Color textOnBrand;

  // Dividers
  final Color divider;

  // Icons
  final Color iconPrimary;
  final Color iconSecondary;

  // Status
  final Color success;
  final Color warning;
  final Color danger;
  final Color dangerSoft;

  // Shadow color
  final Color shadow;

  // Profile extras
  final Color profileAccentBrown;
  final Color profileAccentBrownDark;

  const AppColors({
    required this.background,
    required this.surface,
    required this.surfaceAlt,
    required this.brand,
    required this.brandStrong,
    required this.brandSoft,
    required this.textPrimary,
    required this.textSecondary,
    required this.textOnBrand,
    required this.divider,
    required this.iconPrimary,
    required this.iconSecondary,
    required this.success,
    required this.warning,
    required this.danger,
    required this.dangerSoft,
    required this.shadow,
    required this.profileAccentBrown,
    required this.profileAccentBrownDark,
  });

  static const AppColors light = AppColors(
    background: AppPalette.grey200,
    surface: _C.white,
    surfaceAlt: AppPalette.grey050,
    brand: AppPalette.blue600,
    brandStrong: AppPalette.blue900,
    brandSoft: AppPalette.blue500,
    textPrimary: AppPalette.blue900,
    textSecondary: AppPalette.grey500,
    textOnBrand: _C.white,
    divider: AppPalette.shadow10,
    iconPrimary: AppPalette.blue900,
    iconSecondary: AppPalette.blue900,
    success: AppPalette.green,
    warning: AppPalette.amber,
    danger: AppPalette.red,
    dangerSoft: AppPalette.redSoft,
    shadow: AppPalette.shadow10,
    profileAccentBrown: AppPalette.brown700,
    profileAccentBrownDark: AppPalette.brown900,
  );

  static const AppColors dark = AppColors(
    background: AppPalette.dark900,
    surface: AppPalette.dark700,
    surfaceAlt: AppPalette.dark800,
    brand: AppPalette.dark800,
    brandStrong: AppPalette.dark400,
    brandSoft: AppPalette.dark700,
    textPrimary: AppPalette.dark400,
    textSecondary: AppPalette.dark350,
    textOnBrand: _C.white,
    divider: Colors.transparent,
    iconPrimary: AppPalette.dark400,
    iconSecondary: AppPalette.dark400,
    success: AppPalette.green,
    warning: AppPalette.amber,
    danger: AppPalette.red,
    dangerSoft: AppPalette.redWarm,
    shadow: AppPalette.shadow10,
    profileAccentBrown: AppPalette.brown700,
    profileAccentBrownDark: AppPalette.brown900,
  );

  @override
  AppColors copyWith({
    Color? background,
    Color? surface,
    Color? surfaceAlt,
    Color? brand,
    Color? brandStrong,
    Color? brandSoft,
    Color? textPrimary,
    Color? textSecondary,
    Color? textOnBrand,
    Color? divider,
    Color? iconPrimary,
    Color? iconSecondary,
    Color? success,
    Color? warning,
    Color? danger,
    Color? dangerSoft,
    Color? shadow,
    Color? profileAccentBrown,
    Color? profileAccentBrownDark,
  }) {
    return AppColors(
      background: background ?? this.background,
      surface: surface ?? this.surface,
      surfaceAlt: surfaceAlt ?? this.surfaceAlt,
      brand: brand ?? this.brand,
      brandStrong: brandStrong ?? this.brandStrong,
      brandSoft: brandSoft ?? this.brandSoft,
      textPrimary: textPrimary ?? this.textPrimary,
      textSecondary: textSecondary ?? this.textSecondary,
      textOnBrand: textOnBrand ?? this.textOnBrand,
      divider: divider ?? this.divider,
      iconPrimary: iconPrimary ?? this.iconPrimary,
      iconSecondary: iconSecondary ?? this.iconSecondary,
      success: success ?? this.success,
      warning: warning ?? this.warning,
      danger: danger ?? this.danger,
      dangerSoft: dangerSoft ?? this.dangerSoft,
      shadow: shadow ?? this.shadow,
      profileAccentBrown: profileAccentBrown ?? this.profileAccentBrown,
      profileAccentBrownDark: profileAccentBrownDark ?? this.profileAccentBrownDark,
    );
  }

  @override
  ThemeExtension<AppColors> lerp(ThemeExtension<AppColors>? other, double t) {
    if (other is! AppColors) return this;

    Color l(Color a, Color b) => Color.lerp(a, b, t)!;

    return AppColors(
      background: l(background, other.background),
      surface: l(surface, other.surface),
      surfaceAlt: l(surfaceAlt, other.surfaceAlt),
      brand: l(brand, other.brand),
      brandStrong: l(brandStrong, other.brandStrong),
      brandSoft: l(brandSoft, other.brandSoft),
      textPrimary: l(textPrimary, other.textPrimary),
      textSecondary: l(textSecondary, other.textSecondary),
      textOnBrand: l(textOnBrand, other.textOnBrand),
      divider: l(divider, other.divider),
      iconPrimary: l(iconPrimary, other.iconPrimary),
      iconSecondary: l(iconSecondary, other.iconSecondary),
      success: l(success, other.success),
      warning: l(warning, other.warning),
      danger: l(danger, other.danger),
      dangerSoft: l(dangerSoft, other.dangerSoft),
      shadow: l(shadow, other.shadow),
      profileAccentBrown: l(profileAccentBrown, other.profileAccentBrown),
      profileAccentBrownDark: l(profileAccentBrownDark, other.profileAccentBrownDark),
    );
  }
}

// --- дальше файл без изменений (spacing/radii/shadows/typography/extensions/theme builder) ---
