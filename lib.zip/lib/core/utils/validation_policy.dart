class ValidationPolicy {
  static const int minSys = 50;
  static const int maxSys = 250;

  static const int minDia = 30;
  static const int maxDia = 150;

  static const int minPulse = 30;
  static const int maxPulse = 250;

  static const int maxSysDiaDiff = 110;
}
