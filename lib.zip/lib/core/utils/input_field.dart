enum InputField { systolic, diastolic, pulse, none }
