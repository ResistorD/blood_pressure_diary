enum PressureField { systolic, diastolic, pulse }
