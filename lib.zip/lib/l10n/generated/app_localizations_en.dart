// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get backupJson => 'Резервная копия (JSON)';

  @override
  String get restoreFromBackup => 'Восстановить из копии';

  @override
  String get restoreDialogTitle => 'Восстановление из копии';

  @override
  String get restoreDialogBody =>
      'Это действие заменит все текущие данные приложения (профиль, настройки и записи давления). Продолжить?';

  @override
  String get restoreAction => 'Восстановить';

  @override
  String get dataRestoredSnack => 'Данные восстановлены';

  @override
  String get reminderMorning => 'Утро';

  @override
  String get reminderEvening => 'Вечер';

  @override
  String get reminderTime => 'Время';

  @override
  String get languageRu => 'Русский';

  @override
  String get languageEn => 'English';

  @override
  String get noRecordsForPeriod => 'Нет записей за выбранный период';

  @override
  String get noDataForPeriod => 'Нет данных за этот период';

  @override
  String get noData => 'Нет данных';

  @override
  String get chartsTitle => 'Графики';

  @override
  String get tabPressure => 'Давление';

  @override
  String get tabPulse => 'Пульс';

  @override
  String get periodWeek => 'Неделя';

  @override
  String get periodMonth => 'Месяц';

  @override
  String get periodAll => 'Все';

  @override
  String get avgLabel => 'Среднее:';

  @override
  String get maxLabelShort => 'Макс.:';

  @override
  String get minLabelShort => 'Мин.:';

  @override
  String get bpmUnit => 'уд/мин';

  @override
  String get tagHeader => 'Теги';

  @override
  String tagHeaderWithCount(int count) {
    return 'Теги ($count)';
  }

  @override
  String get tagAfterCoffee => 'После кофе';

  @override
  String get tagAlcohol => 'Алкоголь';

  @override
  String get tagAfterMeal => 'После еды';

  @override
  String get tagAfterWalk => 'После прогулки';

  @override
  String get tagAfterTraining => 'После тренировки';

  @override
  String get tagStress => 'Стресс';

  @override
  String get tagBadSleep => 'Плохой сон';

  @override
  String get tagHeadache => 'Головная боль';

  @override
  String get tagTookMeds => 'Принял лекарство';

  @override
  String get tagMissedDose => 'Пропустил приём';

  @override
  String get bpLevelLow => 'Понижено';

  @override
  String get bpLevelNormal => 'Норма';

  @override
  String get bpLevelElevated => 'Повышено';

  @override
  String get bpLevelHtn1 => 'Гипертония 1';

  @override
  String get bpLevelHtn2 => 'Гипертония 2';

  @override
  String get bpLevelCrisis => 'Кризис';

  @override
  String get notifTitleMeasureNow => 'Пора измерить давление';

  @override
  String get notifBodyDontForget =>
      'Не забудьте внести данные в дневник для контроля здоровья.';

  @override
  String get notifChannelName => 'Напоминания о давлении';

  @override
  String get notifChannelDescription =>
      'Ежедневные уведомления о необходимости замера давления';

  @override
  String get profileAccount => 'Аккаунт';

  @override
  String get profileConnect => 'Подключить';

  @override
  String get profileNotSignedIn => 'Вы не вошли в аккаунт';

  @override
  String get profileSignIn => 'Войти';

  @override
  String get profileLinked => 'Аккаунт подключен';

  @override
  String get profileSignOut => 'Выйти';

  @override
  String get profileChooseSignIn => 'Выберите способ входа';

  @override
  String get profileSystolicLabel => 'Верхнее';

  @override
  String get profileDiastolicLabel => 'Нижнее';

  @override
  String get premiumRemoveAds => 'Убрать рекламу';

  @override
  String get premiumSubtitleOneTime => 'Разовый платеж 2,99 € -  навсегда';

  @override
  String get dobLabel => 'Дата рождения';

  @override
  String get genderShortMale => 'Муж.';

  @override
  String get genderShortFemale => 'Жен.';

  @override
  String get appTitle => 'Дневник давления';

  @override
  String get yourCondition => 'Ваше состояние';

  @override
  String get normalStatus => 'В норме';

  @override
  String get history => 'История';

  @override
  String get systolic => 'Верхнее';

  @override
  String get diastolic => 'Нижнее';

  @override
  String get pulse => 'Пульс';

  @override
  String get addRecord => 'Новая запись';

  @override
  String get save => 'Сохранить';

  @override
  String get cancel => 'Отмена';

  @override
  String get settings => 'Настройки';

  @override
  String get today => 'Сегодня';

  @override
  String get week => 'Неделя';

  @override
  String get month => 'Месяц';

  @override
  String get allShort => 'Все';

  @override
  String get allTime => 'Всё время';

  @override
  String get myDiary => 'Мой дневник';

  @override
  String get recordsOne => 'запись';

  @override
  String get recordsFew => 'записи';

  @override
  String get recordsMany => 'записей';

  @override
  String get profile => 'Профиль';

  @override
  String get language => 'Язык';

  @override
  String get theme => 'Тема';

  @override
  String get unitMmHg => 'мм рт. ст.';

  @override
  String get unitBpm => 'уд/мин';

  @override
  String get noRecords => 'Записей пока нет';

  @override
  String lastMeasurement(String date) {
    return 'Последнее замер: $date';
  }

  @override
  String get pickTime => 'Выберите время';

  @override
  String get pickDate => 'Выберите дату';

  @override
  String get deleteRecordQ => 'Удалить запись?';

  @override
  String get cannotUndo => 'Это действие нельзя отменить.';

  @override
  String get delete => 'Удалить';

  @override
  String get commentHint => 'Комментарий';

  @override
  String get newRecord => 'Новая запись';

  @override
  String get systolicShort => 'Сист.';

  @override
  String get diastolicShort => 'Диаст.';

  @override
  String get reminders => 'Напоминания';

  @override
  String get addReminder => 'Добавить напоминание';

  @override
  String get clearData => 'Очистить данные';

  @override
  String get clearDataConfirm => 'Точно очистить все данные?';

  @override
  String get export => 'Экспорт';

  @override
  String get exportCSV => 'Экспорт в CSV';

  @override
  String get exportPDF => 'Экспорт в PDF';

  @override
  String get contactSupport => 'Написать нам';

  @override
  String get rateApp => 'Оценить приложение';

  @override
  String get versionLabel => 'Версия';

  @override
  String get yes => 'Да';

  @override
  String get no => 'Нет';

  @override
  String get light => 'Светлая';

  @override
  String get dark => 'Тёмная';

  @override
  String get system => 'Системная';

  @override
  String get privacyPolicy => 'Политика конфиденциальности';

  @override
  String get privacyPolicyLastUpdate => 'Обновлено:';

  @override
  String get privacyPolicyFullText => '(текст политики)';

  @override
  String get averageLabel => 'Среднее:';

  @override
  String get minLabel => 'Мин.:';

  @override
  String get maxLabel => 'Макс.:';

  @override
  String get pressureLabel => 'Давление';

  @override
  String get restoreBackupTitle => 'Восстановление из копии';

  @override
  String get restoreBackupConfirm =>
      'Это действие заменит все текущие данные приложения (профиль, настройки и записи давления). Продолжить?';

  @override
  String get restore => 'Восстановить';

  @override
  String get dataRestored => 'Данные восстановлены';

  @override
  String get morning => 'Утро';

  @override
  String get evening => 'Вечер';

  @override
  String get time => 'Время';

  @override
  String get russian => 'Русский';

  @override
  String get account => 'Account';

  @override
  String get accountConnected => 'Account connected';

  @override
  String get accountNotConnected => 'You are not signed in';

  @override
  String get chooseSignIn => 'Choose sign-in method';

  @override
  String get connect => 'Connect';

  @override
  String get signIn => 'Sign in';

  @override
  String get signOut => 'Sign out';

  @override
  String get name => 'Name';

  @override
  String get gender => 'Gender';

  @override
  String get maleShort => 'Male';

  @override
  String get femaleShort => 'Female';

  @override
  String get birthDate => 'Birth date';

  @override
  String get pressureNorms => 'BP targets';

  @override
  String get upper => 'Systolic';

  @override
  String get lower => 'Diastolic';

  @override
  String get removeAds => 'Remove ads';

  @override
  String get removeAdsSubtitle => 'One-time purchase €2.99 — forever';

  @override
  String get bpm => 'bpm';
}
