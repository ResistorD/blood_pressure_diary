import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_ru.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'generated/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('ru'),
  ];

  /// No description provided for @backupJson.
  ///
  /// In ru, this message translates to:
  /// **'Backup (JSON)'**
  String get backupJson;

  /// No description provided for @restoreFromBackup.
  ///
  /// In ru, this message translates to:
  /// **'Restore from backup'**
  String get restoreFromBackup;

  /// No description provided for @restoreDialogTitle.
  ///
  /// In ru, this message translates to:
  /// **'Restore from backup'**
  String get restoreDialogTitle;

  /// No description provided for @restoreDialogBody.
  ///
  /// In ru, this message translates to:
  /// **'This action will replace all current app data (profile, settings, and pressure records). Continue?'**
  String get restoreDialogBody;

  /// No description provided for @restoreAction.
  ///
  /// In ru, this message translates to:
  /// **'Restore'**
  String get restoreAction;

  /// No description provided for @dataRestoredSnack.
  ///
  /// In ru, this message translates to:
  /// **'Data restored'**
  String get dataRestoredSnack;

  /// No description provided for @reminderMorning.
  ///
  /// In ru, this message translates to:
  /// **'Morning'**
  String get reminderMorning;

  /// No description provided for @reminderEvening.
  ///
  /// In ru, this message translates to:
  /// **'Evening'**
  String get reminderEvening;

  /// No description provided for @reminderTime.
  ///
  /// In ru, this message translates to:
  /// **'Time'**
  String get reminderTime;

  /// No description provided for @languageRu.
  ///
  /// In ru, this message translates to:
  /// **'Russian'**
  String get languageRu;

  /// No description provided for @languageEn.
  ///
  /// In ru, this message translates to:
  /// **'English'**
  String get languageEn;

  /// No description provided for @noRecordsForPeriod.
  ///
  /// In ru, this message translates to:
  /// **'No records for the selected period'**
  String get noRecordsForPeriod;

  /// No description provided for @noDataForPeriod.
  ///
  /// In ru, this message translates to:
  /// **'No data for this period'**
  String get noDataForPeriod;

  /// No description provided for @noData.
  ///
  /// In ru, this message translates to:
  /// **'No data'**
  String get noData;

  /// No description provided for @chartsTitle.
  ///
  /// In ru, this message translates to:
  /// **'Charts'**
  String get chartsTitle;

  /// No description provided for @tabPressure.
  ///
  /// In ru, this message translates to:
  /// **'Pressure'**
  String get tabPressure;

  /// No description provided for @tabPulse.
  ///
  /// In ru, this message translates to:
  /// **'Pulse'**
  String get tabPulse;

  /// No description provided for @periodWeek.
  ///
  /// In ru, this message translates to:
  /// **'Week'**
  String get periodWeek;

  /// No description provided for @periodMonth.
  ///
  /// In ru, this message translates to:
  /// **'Month'**
  String get periodMonth;

  /// No description provided for @periodAll.
  ///
  /// In ru, this message translates to:
  /// **'All'**
  String get periodAll;

  /// No description provided for @avgLabel.
  ///
  /// In ru, this message translates to:
  /// **'Avg:'**
  String get avgLabel;

  /// No description provided for @maxLabelShort.
  ///
  /// In ru, this message translates to:
  /// **'Max:'**
  String get maxLabelShort;

  /// No description provided for @minLabelShort.
  ///
  /// In ru, this message translates to:
  /// **'Min:'**
  String get minLabelShort;

  /// No description provided for @bpmUnit.
  ///
  /// In ru, this message translates to:
  /// **'bpm'**
  String get bpmUnit;

  /// No description provided for @tagHeader.
  ///
  /// In ru, this message translates to:
  /// **'Tags'**
  String get tagHeader;

  /// No description provided for @tagHeaderWithCount.
  ///
  /// In ru, this message translates to:
  /// **'Tags ({count})'**
  String tagHeaderWithCount(int count);

  /// No description provided for @tagAfterCoffee.
  ///
  /// In ru, this message translates to:
  /// **'After coffee'**
  String get tagAfterCoffee;

  /// No description provided for @tagAlcohol.
  ///
  /// In ru, this message translates to:
  /// **'Alcohol'**
  String get tagAlcohol;

  /// No description provided for @tagAfterMeal.
  ///
  /// In ru, this message translates to:
  /// **'After meal'**
  String get tagAfterMeal;

  /// No description provided for @tagAfterWalk.
  ///
  /// In ru, this message translates to:
  /// **'After walk'**
  String get tagAfterWalk;

  /// No description provided for @tagAfterTraining.
  ///
  /// In ru, this message translates to:
  /// **'After workout'**
  String get tagAfterTraining;

  /// No description provided for @tagStress.
  ///
  /// In ru, this message translates to:
  /// **'Stress'**
  String get tagStress;

  /// No description provided for @tagBadSleep.
  ///
  /// In ru, this message translates to:
  /// **'Poor sleep'**
  String get tagBadSleep;

  /// No description provided for @tagHeadache.
  ///
  /// In ru, this message translates to:
  /// **'Headache'**
  String get tagHeadache;

  /// No description provided for @tagTookMeds.
  ///
  /// In ru, this message translates to:
  /// **'Took meds'**
  String get tagTookMeds;

  /// No description provided for @tagMissedDose.
  ///
  /// In ru, this message translates to:
  /// **'Missed dose'**
  String get tagMissedDose;

  /// No description provided for @bpLevelLow.
  ///
  /// In ru, this message translates to:
  /// **'Low'**
  String get bpLevelLow;

  /// No description provided for @bpLevelNormal.
  ///
  /// In ru, this message translates to:
  /// **'Normal'**
  String get bpLevelNormal;

  /// No description provided for @bpLevelElevated.
  ///
  /// In ru, this message translates to:
  /// **'Elevated'**
  String get bpLevelElevated;

  /// No description provided for @bpLevelHtn1.
  ///
  /// In ru, this message translates to:
  /// **'Hypertension 1'**
  String get bpLevelHtn1;

  /// No description provided for @bpLevelHtn2.
  ///
  /// In ru, this message translates to:
  /// **'Hypertension 2'**
  String get bpLevelHtn2;

  /// No description provided for @bpLevelCrisis.
  ///
  /// In ru, this message translates to:
  /// **'Crisis'**
  String get bpLevelCrisis;

  /// No description provided for @notifTitleMeasureNow.
  ///
  /// In ru, this message translates to:
  /// **'Time to measure blood pressure'**
  String get notifTitleMeasureNow;

  /// No description provided for @notifBodyDontForget.
  ///
  /// In ru, this message translates to:
  /// **'Don’t forget to log your measurements to track your health.'**
  String get notifBodyDontForget;

  /// No description provided for @notifChannelName.
  ///
  /// In ru, this message translates to:
  /// **'Blood pressure reminders'**
  String get notifChannelName;

  /// No description provided for @notifChannelDescription.
  ///
  /// In ru, this message translates to:
  /// **'Daily reminders to measure blood pressure'**
  String get notifChannelDescription;

  /// No description provided for @profileAccount.
  ///
  /// In ru, this message translates to:
  /// **'Account'**
  String get profileAccount;

  /// No description provided for @profileConnect.
  ///
  /// In ru, this message translates to:
  /// **'Connect'**
  String get profileConnect;

  /// No description provided for @profileNotSignedIn.
  ///
  /// In ru, this message translates to:
  /// **'You are not signed in'**
  String get profileNotSignedIn;

  /// No description provided for @profileSignIn.
  ///
  /// In ru, this message translates to:
  /// **'Sign in'**
  String get profileSignIn;

  /// No description provided for @profileLinked.
  ///
  /// In ru, this message translates to:
  /// **'Account connected'**
  String get profileLinked;

  /// No description provided for @profileSignOut.
  ///
  /// In ru, this message translates to:
  /// **'Sign out'**
  String get profileSignOut;

  /// No description provided for @profileChooseSignIn.
  ///
  /// In ru, this message translates to:
  /// **'Choose a sign-in method'**
  String get profileChooseSignIn;

  /// No description provided for @profileSystolicLabel.
  ///
  /// In ru, this message translates to:
  /// **'Systolic'**
  String get profileSystolicLabel;

  /// No description provided for @profileDiastolicLabel.
  ///
  /// In ru, this message translates to:
  /// **'Diastolic'**
  String get profileDiastolicLabel;

  /// No description provided for @premiumRemoveAds.
  ///
  /// In ru, this message translates to:
  /// **'Remove ads'**
  String get premiumRemoveAds;

  /// No description provided for @premiumSubtitleOneTime.
  ///
  /// In ru, this message translates to:
  /// **'One-time payment €2.99 — forever'**
  String get premiumSubtitleOneTime;

  /// No description provided for @dobLabel.
  ///
  /// In ru, this message translates to:
  /// **'Date of birth'**
  String get dobLabel;

  /// No description provided for @genderShortMale.
  ///
  /// In ru, this message translates to:
  /// **'M'**
  String get genderShortMale;

  /// No description provided for @genderShortFemale.
  ///
  /// In ru, this message translates to:
  /// **'F'**
  String get genderShortFemale;

  /// No description provided for @appTitle.
  ///
  /// In ru, this message translates to:
  /// **'BP Diary'**
  String get appTitle;

  /// No description provided for @yourCondition.
  ///
  /// In ru, this message translates to:
  /// **'Your condition'**
  String get yourCondition;

  /// No description provided for @normalStatus.
  ///
  /// In ru, this message translates to:
  /// **'Normal'**
  String get normalStatus;

  /// No description provided for @history.
  ///
  /// In ru, this message translates to:
  /// **'History'**
  String get history;

  /// No description provided for @systolic.
  ///
  /// In ru, this message translates to:
  /// **'Systolic'**
  String get systolic;

  /// No description provided for @diastolic.
  ///
  /// In ru, this message translates to:
  /// **'Diastolic'**
  String get diastolic;

  /// No description provided for @pulse.
  ///
  /// In ru, this message translates to:
  /// **'Pulse'**
  String get pulse;

  /// No description provided for @addRecord.
  ///
  /// In ru, this message translates to:
  /// **'New Record'**
  String get addRecord;

  /// No description provided for @save.
  ///
  /// In ru, this message translates to:
  /// **'Save'**
  String get save;

  /// No description provided for @cancel.
  ///
  /// In ru, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @settings.
  ///
  /// In ru, this message translates to:
  /// **'Settings'**
  String get settings;

  /// No description provided for @today.
  ///
  /// In ru, this message translates to:
  /// **'Today'**
  String get today;

  /// No description provided for @week.
  ///
  /// In ru, this message translates to:
  /// **'Week'**
  String get week;

  /// No description provided for @month.
  ///
  /// In ru, this message translates to:
  /// **'Month'**
  String get month;

  /// No description provided for @allShort.
  ///
  /// In ru, this message translates to:
  /// **'All'**
  String get allShort;

  /// No description provided for @allTime.
  ///
  /// In ru, this message translates to:
  /// **'All time'**
  String get allTime;

  /// No description provided for @myDiary.
  ///
  /// In ru, this message translates to:
  /// **'My diary'**
  String get myDiary;

  /// No description provided for @recordsOne.
  ///
  /// In ru, this message translates to:
  /// **'record'**
  String get recordsOne;

  /// No description provided for @recordsFew.
  ///
  /// In ru, this message translates to:
  /// **'records'**
  String get recordsFew;

  /// No description provided for @recordsMany.
  ///
  /// In ru, this message translates to:
  /// **'records'**
  String get recordsMany;

  /// No description provided for @profile.
  ///
  /// In ru, this message translates to:
  /// **'Profile'**
  String get profile;

  /// No description provided for @language.
  ///
  /// In ru, this message translates to:
  /// **'Language'**
  String get language;

  /// No description provided for @theme.
  ///
  /// In ru, this message translates to:
  /// **'Theme'**
  String get theme;

  /// No description provided for @unitMmHg.
  ///
  /// In ru, this message translates to:
  /// **'mmHg'**
  String get unitMmHg;

  /// No description provided for @unitBpm.
  ///
  /// In ru, this message translates to:
  /// **'bpm'**
  String get unitBpm;

  /// No description provided for @noRecords.
  ///
  /// In ru, this message translates to:
  /// **'No records yet'**
  String get noRecords;

  /// No description provided for @lastMeasurement.
  ///
  /// In ru, this message translates to:
  /// **'Last measurement: {date}'**
  String lastMeasurement(String date);

  /// No description provided for @pickTime.
  ///
  /// In ru, this message translates to:
  /// **'Pick time'**
  String get pickTime;

  /// No description provided for @pickDate.
  ///
  /// In ru, this message translates to:
  /// **'Pick date'**
  String get pickDate;

  /// No description provided for @deleteRecordQ.
  ///
  /// In ru, this message translates to:
  /// **'Delete record?'**
  String get deleteRecordQ;

  /// No description provided for @cannotUndo.
  ///
  /// In ru, this message translates to:
  /// **'This action cannot be undone.'**
  String get cannotUndo;

  /// No description provided for @delete.
  ///
  /// In ru, this message translates to:
  /// **'Delete'**
  String get delete;

  /// No description provided for @commentHint.
  ///
  /// In ru, this message translates to:
  /// **'Comment'**
  String get commentHint;

  /// No description provided for @newRecord.
  ///
  /// In ru, this message translates to:
  /// **'New record'**
  String get newRecord;

  /// No description provided for @systolicShort.
  ///
  /// In ru, this message translates to:
  /// **'SYS'**
  String get systolicShort;

  /// No description provided for @diastolicShort.
  ///
  /// In ru, this message translates to:
  /// **'DIA'**
  String get diastolicShort;

  /// No description provided for @reminders.
  ///
  /// In ru, this message translates to:
  /// **'Reminders'**
  String get reminders;

  /// No description provided for @addReminder.
  ///
  /// In ru, this message translates to:
  /// **'Add reminder'**
  String get addReminder;

  /// No description provided for @clearData.
  ///
  /// In ru, this message translates to:
  /// **'Clear data'**
  String get clearData;

  /// No description provided for @clearDataConfirm.
  ///
  /// In ru, this message translates to:
  /// **'Clear all data?'**
  String get clearDataConfirm;

  /// No description provided for @export.
  ///
  /// In ru, this message translates to:
  /// **'Export'**
  String get export;

  /// No description provided for @exportCSV.
  ///
  /// In ru, this message translates to:
  /// **'Export to CSV'**
  String get exportCSV;

  /// No description provided for @exportPDF.
  ///
  /// In ru, this message translates to:
  /// **'Export to PDF'**
  String get exportPDF;

  /// No description provided for @contactSupport.
  ///
  /// In ru, this message translates to:
  /// **'Contact us'**
  String get contactSupport;

  /// No description provided for @rateApp.
  ///
  /// In ru, this message translates to:
  /// **'Rate app'**
  String get rateApp;

  /// No description provided for @versionLabel.
  ///
  /// In ru, this message translates to:
  /// **'Version'**
  String get versionLabel;

  /// No description provided for @yes.
  ///
  /// In ru, this message translates to:
  /// **'Yes'**
  String get yes;

  /// No description provided for @no.
  ///
  /// In ru, this message translates to:
  /// **'No'**
  String get no;

  /// No description provided for @light.
  ///
  /// In ru, this message translates to:
  /// **'Light'**
  String get light;

  /// No description provided for @dark.
  ///
  /// In ru, this message translates to:
  /// **'Dark'**
  String get dark;

  /// No description provided for @system.
  ///
  /// In ru, this message translates to:
  /// **'System'**
  String get system;

  /// No description provided for @privacyPolicy.
  ///
  /// In ru, this message translates to:
  /// **'Privacy Policy'**
  String get privacyPolicy;

  /// No description provided for @privacyPolicyLastUpdate.
  ///
  /// In ru, this message translates to:
  /// **'Last updated:'**
  String get privacyPolicyLastUpdate;

  /// No description provided for @privacyPolicyFullText.
  ///
  /// In ru, this message translates to:
  /// **'(privacy policy text)'**
  String get privacyPolicyFullText;

  /// No description provided for @averageLabel.
  ///
  /// In ru, this message translates to:
  /// **'Average:'**
  String get averageLabel;

  /// No description provided for @minLabel.
  ///
  /// In ru, this message translates to:
  /// **'Min.:'**
  String get minLabel;

  /// No description provided for @maxLabel.
  ///
  /// In ru, this message translates to:
  /// **'Max.:'**
  String get maxLabel;

  /// No description provided for @pressureLabel.
  ///
  /// In ru, this message translates to:
  /// **'Pressure'**
  String get pressureLabel;

  /// No description provided for @restoreBackupTitle.
  ///
  /// In ru, this message translates to:
  /// **'Restore from backup'**
  String get restoreBackupTitle;

  /// No description provided for @restoreBackupConfirm.
  ///
  /// In ru, this message translates to:
  /// **'This will replace all current app data (profile, settings, and blood pressure records). Continue?'**
  String get restoreBackupConfirm;

  /// No description provided for @restore.
  ///
  /// In ru, this message translates to:
  /// **'Restore'**
  String get restore;

  /// No description provided for @dataRestored.
  ///
  /// In ru, this message translates to:
  /// **'Data restored'**
  String get dataRestored;

  /// No description provided for @morning.
  ///
  /// In ru, this message translates to:
  /// **'Morning'**
  String get morning;

  /// No description provided for @evening.
  ///
  /// In ru, this message translates to:
  /// **'Evening'**
  String get evening;

  /// No description provided for @time.
  ///
  /// In ru, this message translates to:
  /// **'Time'**
  String get time;

  /// No description provided for @russian.
  ///
  /// In ru, this message translates to:
  /// **'Russian'**
  String get russian;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Аккаунт'**
  String get account;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Аккаунт подключен'**
  String get accountConnected;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Вы не вошли в аккаунт'**
  String get accountNotConnected;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Выберите способ входа'**
  String get chooseSignIn;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Подключить'**
  String get connect;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Войти'**
  String get signIn;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Выйти'**
  String get signOut;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Имя'**
  String get name;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Пол'**
  String get gender;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Муж.'**
  String get maleShort;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Жен.'**
  String get femaleShort;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Дата рождения'**
  String get birthDate;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Нормы давления'**
  String get pressureNorms;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Верхнее'**
  String get upper;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Нижнее'**
  String get lower;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Убрать рекламу'**
  String get removeAds;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'Разовый платеж 2,99 € — навсегда'**
  String get removeAdsSubtitle;

  /// auto-added
  ///
  /// In ru, this message translates to:
  /// **'уд/мин'**
  String get bpm;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['en', 'ru'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
    case 'ru':
      return AppLocalizationsRu();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
