// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Russian (`ru`).
class AppLocalizationsRu extends AppLocalizations {
  AppLocalizationsRu([String locale = 'ru']) : super(locale);

  @override
  String get backupJson => 'Backup (JSON)';

  @override
  String get restoreFromBackup => 'Restore from backup';

  @override
  String get restoreDialogTitle => 'Restore from backup';

  @override
  String get restoreDialogBody =>
      'This action will replace all current app data (profile, settings, and pressure records). Continue?';

  @override
  String get restoreAction => 'Restore';

  @override
  String get dataRestoredSnack => 'Data restored';

  @override
  String get reminderMorning => 'Morning';

  @override
  String get reminderEvening => 'Evening';

  @override
  String get reminderTime => 'Time';

  @override
  String get languageRu => 'Russian';

  @override
  String get languageEn => 'English';

  @override
  String get noRecordsForPeriod => 'No records for the selected period';

  @override
  String get noDataForPeriod => 'No data for this period';

  @override
  String get noData => 'No data';

  @override
  String get chartsTitle => 'Charts';

  @override
  String get tabPressure => 'Pressure';

  @override
  String get tabPulse => 'Pulse';

  @override
  String get periodWeek => 'Week';

  @override
  String get periodMonth => 'Month';

  @override
  String get periodAll => 'All';

  @override
  String get avgLabel => 'Avg:';

  @override
  String get maxLabelShort => 'Max:';

  @override
  String get minLabelShort => 'Min:';

  @override
  String get bpmUnit => 'bpm';

  @override
  String get tagHeader => 'Tags';

  @override
  String tagHeaderWithCount(int count) {
    return 'Tags ($count)';
  }

  @override
  String get tagAfterCoffee => 'After coffee';

  @override
  String get tagAlcohol => 'Alcohol';

  @override
  String get tagAfterMeal => 'After meal';

  @override
  String get tagAfterWalk => 'After walk';

  @override
  String get tagAfterTraining => 'After workout';

  @override
  String get tagStress => 'Stress';

  @override
  String get tagBadSleep => 'Poor sleep';

  @override
  String get tagHeadache => 'Headache';

  @override
  String get tagTookMeds => 'Took meds';

  @override
  String get tagMissedDose => 'Missed dose';

  @override
  String get bpLevelLow => 'Low';

  @override
  String get bpLevelNormal => 'Normal';

  @override
  String get bpLevelElevated => 'Elevated';

  @override
  String get bpLevelHtn1 => 'Hypertension 1';

  @override
  String get bpLevelHtn2 => 'Hypertension 2';

  @override
  String get bpLevelCrisis => 'Crisis';

  @override
  String get notifTitleMeasureNow => 'Time to measure blood pressure';

  @override
  String get notifBodyDontForget =>
      'Don’t forget to log your measurements to track your health.';

  @override
  String get notifChannelName => 'Blood pressure reminders';

  @override
  String get notifChannelDescription =>
      'Daily reminders to measure blood pressure';

  @override
  String get profileAccount => 'Account';

  @override
  String get profileConnect => 'Connect';

  @override
  String get profileNotSignedIn => 'You are not signed in';

  @override
  String get profileSignIn => 'Sign in';

  @override
  String get profileLinked => 'Account connected';

  @override
  String get profileSignOut => 'Sign out';

  @override
  String get profileChooseSignIn => 'Choose a sign-in method';

  @override
  String get profileSystolicLabel => 'Systolic';

  @override
  String get profileDiastolicLabel => 'Diastolic';

  @override
  String get premiumRemoveAds => 'Remove ads';

  @override
  String get premiumSubtitleOneTime => 'One-time payment €2.99 — forever';

  @override
  String get dobLabel => 'Date of birth';

  @override
  String get genderShortMale => 'M';

  @override
  String get genderShortFemale => 'F';

  @override
  String get appTitle => 'BP Diary';

  @override
  String get yourCondition => 'Your condition';

  @override
  String get normalStatus => 'Normal';

  @override
  String get history => 'History';

  @override
  String get systolic => 'Systolic';

  @override
  String get diastolic => 'Diastolic';

  @override
  String get pulse => 'Pulse';

  @override
  String get addRecord => 'New Record';

  @override
  String get save => 'Save';

  @override
  String get cancel => 'Cancel';

  @override
  String get settings => 'Settings';

  @override
  String get today => 'Today';

  @override
  String get week => 'Week';

  @override
  String get month => 'Month';

  @override
  String get allShort => 'All';

  @override
  String get allTime => 'All time';

  @override
  String get myDiary => 'My diary';

  @override
  String get recordsOne => 'record';

  @override
  String get recordsFew => 'records';

  @override
  String get recordsMany => 'records';

  @override
  String get profile => 'Profile';

  @override
  String get language => 'Language';

  @override
  String get theme => 'Theme';

  @override
  String get unitMmHg => 'mmHg';

  @override
  String get unitBpm => 'bpm';

  @override
  String get noRecords => 'No records yet';

  @override
  String lastMeasurement(String date) {
    return 'Last measurement: $date';
  }

  @override
  String get pickTime => 'Pick time';

  @override
  String get pickDate => 'Pick date';

  @override
  String get deleteRecordQ => 'Delete record?';

  @override
  String get cannotUndo => 'This action cannot be undone.';

  @override
  String get delete => 'Delete';

  @override
  String get commentHint => 'Comment';

  @override
  String get newRecord => 'New record';

  @override
  String get systolicShort => 'SYS';

  @override
  String get diastolicShort => 'DIA';

  @override
  String get reminders => 'Reminders';

  @override
  String get addReminder => 'Add reminder';

  @override
  String get clearData => 'Clear data';

  @override
  String get clearDataConfirm => 'Clear all data?';

  @override
  String get export => 'Export';

  @override
  String get exportCSV => 'Export to CSV';

  @override
  String get exportPDF => 'Export to PDF';

  @override
  String get contactSupport => 'Contact us';

  @override
  String get rateApp => 'Rate app';

  @override
  String get versionLabel => 'Version';

  @override
  String get yes => 'Yes';

  @override
  String get no => 'No';

  @override
  String get light => 'Light';

  @override
  String get dark => 'Dark';

  @override
  String get system => 'System';

  @override
  String get privacyPolicy => 'Privacy Policy';

  @override
  String get privacyPolicyLastUpdate => 'Last updated:';

  @override
  String get privacyPolicyFullText => '(privacy policy text)';

  @override
  String get averageLabel => 'Average:';

  @override
  String get minLabel => 'Min.:';

  @override
  String get maxLabel => 'Max.:';

  @override
  String get pressureLabel => 'Pressure';

  @override
  String get restoreBackupTitle => 'Restore from backup';

  @override
  String get restoreBackupConfirm =>
      'This will replace all current app data (profile, settings, and blood pressure records). Continue?';

  @override
  String get restore => 'Restore';

  @override
  String get dataRestored => 'Data restored';

  @override
  String get morning => 'Morning';

  @override
  String get evening => 'Evening';

  @override
  String get time => 'Time';

  @override
  String get russian => 'Russian';

  @override
  String get account => 'Аккаунт';

  @override
  String get accountConnected => 'Аккаунт подключен';

  @override
  String get accountNotConnected => 'Вы не вошли в аккаунт';

  @override
  String get chooseSignIn => 'Выберите способ входа';

  @override
  String get connect => 'Подключить';

  @override
  String get signIn => 'Войти';

  @override
  String get signOut => 'Выйти';

  @override
  String get name => 'Имя';

  @override
  String get gender => 'Пол';

  @override
  String get maleShort => 'Муж.';

  @override
  String get femaleShort => 'Жен.';

  @override
  String get birthDate => 'Дата рождения';

  @override
  String get pressureNorms => 'Нормы давления';

  @override
  String get upper => 'Верхнее';

  @override
  String get lower => 'Нижнее';

  @override
  String get removeAds => 'Убрать рекламу';

  @override
  String get removeAdsSubtitle => 'Разовый платеж 2,99 € — навсегда';

  @override
  String get bpm => 'уд/мин';
}
