import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/theme/scale.dart';
import '../../../../core/utils/blood_pressure_color_utils.dart';
import '../../../profile/presentation/bloc/profile_cubit.dart';
import '../../../profile/presentation/bloc/profile_state.dart';
import '../../data/blood_pressure_model.dart';

String _tr(BuildContext context, {required String ru, required String en}) {
  final code = Localizations.localeOf(context).languageCode.toLowerCase();
  return code == 'ru' ? ru : en;
}

String tagLabel(BuildContext context, String raw) {
  // Не используем AppLocalizations-ключи, которых может не быть.
  // Переводим стабильным способом: RU/EN по locale.
  switch (raw) {
    case 'afterCoffee':
    case 'coffee':
    case 'После кофе':
      return _tr(context, ru: 'После кофе', en: 'After coffee');

    case 'afterMeal':
    case 'meal':
    case 'После еды':
      return _tr(context, ru: 'После еды', en: 'After meal');

    case 'stress':
    case 'Стресс':
      return _tr(context, ru: 'Стресс', en: 'Stress');

    case 'training':
    case 'workout':
    case 'Тренировка':
    case 'После нагрузки/тренировки':
      return _tr(context, ru: 'Тренировка', en: 'Workout');

    case 'walk':
    case 'Прогулка':
    case 'После прогулки':
      return _tr(context, ru: 'Прогулка', en: 'Walk');

    case 'badSleep':
    case 'sleep':
    case 'Плохой сон':
      return _tr(context, ru: 'Плохой сон', en: 'Poor sleep');

    case 'headache':
    case 'Головная боль':
      return _tr(context, ru: 'Головная боль', en: 'Headache');

    case 'meds':
    case 'medicine':
    case 'Лекарства':
    case 'Принял лекарство':
      return _tr(context, ru: 'Лекарства', en: 'Meds');

    case 'missedMeds':
    case 'Пропуск лекарств':
    case 'Пропустил приём':
      return _tr(context, ru: 'Пропуск лекарств', en: 'Missed meds');

    case 'alcohol':
    case 'Алкоголь':
      return _tr(context, ru: 'Алкоголь', en: 'Alcohol');

    default:
      return raw;
  }
}

class RecordListItem extends StatelessWidget {
  String _formatTime(BuildContext context, DateTime dt) {
    final locale = Localizations.localeOf(context).languageCode;
    return DateFormat('HH:mm', locale).format(dt);
  }

  // Иконки определяем по «сырому» тегу (RU/EN варианты), чтобы не зависеть от локали.
  static const Map<String, String> _tagIconByRaw = {
    // coffee
    'afterCoffee': 'assets/icons/tags/coffee.svg',
    'coffee': 'assets/icons/tags/coffee.svg',
    'После кофе': 'assets/icons/tags/coffee.svg',

    // meal
    'afterMeal': 'assets/icons/tags/hamburger.svg',
    'meal': 'assets/icons/tags/hamburger.svg',
    'После еды': 'assets/icons/tags/hamburger.svg',

    // walk
    'walk': 'assets/icons/tags/walk.svg',
    'Прогулка': 'assets/icons/tags/walk.svg',
    'После прогулки': 'assets/icons/tags/walk.svg',

    // workout
    'training': 'assets/icons/tags/training.svg',
    'workout': 'assets/icons/tags/training.svg',
    'Тренировка': 'assets/icons/tags/training.svg',
    'После нагрузки/тренировки': 'assets/icons/tags/training.svg',

    // stress
    'stress': 'assets/icons/tags/stress.svg',
    'Стресс': 'assets/icons/tags/stress.svg',

    // sleep
    'badSleep': 'assets/icons/tags/sleep.svg',
    'sleep': 'assets/icons/tags/sleep.svg',
    'Плохой сон': 'assets/icons/tags/sleep.svg',

    // meds
    'meds': 'assets/icons/tags/meds.svg',
    'medicine': 'assets/icons/tags/meds.svg',
    'Лекарства': 'assets/icons/tags/meds.svg',
    'Принял лекарство': 'assets/icons/tags/meds.svg',

    // missed meds
    'missedMeds': 'assets/icons/tags/missed_meds.svg',
    'Пропуск лекарств': 'assets/icons/tags/missed_meds.svg',
    'Пропустил приём': 'assets/icons/tags/missed_meds.svg',

    // alcohol
    'alcohol': 'assets/icons/tags/alcohol.svg',
    'Алкоголь': 'assets/icons/tags/alcohol.svg',

    // headache
    'headache': 'assets/icons/tags/headache.svg',
    'Головная боль': 'assets/icons/tags/headache.svg',
  };

  final BloodPressureRecord record;
  final VoidCallback? onTap;

  const RecordListItem({
    super.key,
    required this.record,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final profileState = context.watch<ProfileCubit>().state;
    int targetSys = 120;
    int targetDia = 80;
    if (profileState is ProfileLoaded) {
      targetSys = profileState.profile.targetSystolic;
      targetDia = profileState.profile.targetDiastolic;
    }

    final c = context.appColors;
    final s = context.appSpace;
    final r = context.appRadii;
    final sh = context.appShadow;
    final tx = context.appText;

    final timeW = dp(context, s.s56);
    final dotD = dp(context, s.s10 + s.s4 + s.s1); // 15
    final timeGap = dp(context, s.s8);
    final dotGap = dp(context, s.s12);

    final iconSize = dp(context, s.s22);
    final iconGap = dp(context, s.s6);
    final blockGap = dp(context, s.s8);

    final cardR = dp(context, r.r5);
    final padH = dp(context, s.s20);

    final note = (record.note ?? '').trim();
    final hasNote = note.isNotEmpty;

    final tags = record.tags;
    final hasTags = tags.isNotEmpty;

    final hasMeta = hasNote || hasTags;

    final rowH = dp(context, hasMeta ? s.s72 : s.s56);
    final padV = dp(context, hasMeta ? s.s8 : s.s10);

    final valueStyle = TextStyle(
      fontFamily: tx.family,
      fontSize: sp(context, tx.fs22),
      fontWeight: tx.w700,
      color: c.textPrimary,
      height: 1.0,
    );

    final timeStyle = TextStyle(
      fontFamily: tx.family,
      fontSize: sp(context, tx.fs16),
      fontWeight: tx.w400,
      color: c.textPrimary,
      height: 1.0,
    );

    final noteStyle = TextStyle(
      fontFamily: tx.family,
      fontSize: sp(context, tx.fs14),
      fontWeight: tx.w400,
      color: c.textSecondary,
      height: 1.0,
    );

    final cardBg = isDark ? AppPalette.dark700 : c.surface;
    final iconColor = c.iconPrimary.withValues(alpha: 0.75);

    final leftTopPad = dp(context, hasMeta ? s.s12 : s.s18);
    final dotTopPad = dp(context, hasMeta ? s.s12 : s.s20);

    final dotColor = BloodPressureColorUtils.getIndicatorColor(
      context,
      systolic: record.systolic,
      diastolic: record.diastolic,
      targetSystolic: targetSys,
      targetDiastolic: targetDia,
    );

    return SizedBox(
      height: rowH,
      child: InkWell(
        onTap: onTap,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: timeW,
              child: Padding(
                padding: EdgeInsets.only(top: leftTopPad),
                child: Text(_formatTime(context, record.dateTime), style: timeStyle),
              ),
            ),
            SizedBox(width: timeGap),
            Padding(
              padding: EdgeInsets.only(top: dotTopPad),
              child: Container(
                width: dotD,
                height: dotD,
                decoration: BoxDecoration(color: dotColor, shape: BoxShape.circle),
              ),
            ),
            SizedBox(width: dotGap),
            Expanded(
              child: Container(
                height: rowH,
                padding: EdgeInsets.symmetric(horizontal: padH, vertical: padV),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(cardR),
                  boxShadow: [sh.card],
                ),
                child: hasMeta
                    ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _MainRow(
                        record: record,
                        valueStyle: valueStyle,
                        iconSize: iconSize,
                        iconGap: iconGap,
                        blockGap: blockGap,
                        iconColor: iconColor,
                      ),
                      SizedBox(height: dp(context, s.s8)),
                      _TagsMetaRow(
                        tags: tags,
                        note: note,
                        noteStyle: noteStyle,
                        iconColor: iconColor,
                        iconSize: dp(context, s.s14),
                        gap: dp(context, s.s6),
                      ),
                    ],
                  ),
                )
                    : Center(
                  child: _MainRow(
                    record: record,
                    valueStyle: valueStyle,
                    iconSize: iconSize,
                    iconGap: iconGap,
                    blockGap: blockGap,
                    iconColor: iconColor,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TagsMetaRow extends StatelessWidget {
  final List<String> tags;
  final String note;
  final TextStyle noteStyle;
  final Color iconColor;
  final double iconSize;
  final double gap;

  const _TagsMetaRow({
    required this.tags,
    required this.note,
    required this.noteStyle,
    required this.iconColor,
    required this.iconSize,
    required this.gap,
  });

  @override
  Widget build(BuildContext context) {
    final icons = <String>[];
    for (final t in tags) {
      final p = RecordListItem._tagIconByRaw[t];
      if (p != null) icons.add(p);
    }

    final showText = note.trim().isNotEmpty || tags.isEmpty;
    final text = note.trim().isNotEmpty ? note.trim() : tags.map((t) => tagLabel(context, t)).join(', ');

    return Row(
      children: [
        if (icons.isNotEmpty)
          Flexible(
            flex: 0,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final p in icons.take(4)) ...[
                  SvgPicture.asset(
                    p,
                    width: iconSize,
                    height: iconSize,
                  ),
                  SizedBox(width: gap),
                ],
              ],
            ),
          ),
        if (icons.isNotEmpty && showText) SizedBox(width: gap),
        if (showText)
          Expanded(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: noteStyle,
            ),
          ),
      ],
    );
  }
}

class _MainRow extends StatelessWidget {
  final BloodPressureRecord record;
  final TextStyle valueStyle;
  final double iconSize;
  final double iconGap;
  final double blockGap;
  final Color iconColor;

  const _MainRow({
    required this.record,
    required this.valueStyle,
    required this.iconSize,
    required this.iconGap,
    required this.blockGap,
    required this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              child: Text(
                '${record.systolic}/${record.diastolic}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: valueStyle,
              ),
            ),
            SizedBox(width: iconGap),
            SvgPicture.asset(
              'assets/arrow-up-down.svg',
              width: iconSize,
              height: iconSize,
              colorFilter: ColorFilter.mode(iconColor, BlendMode.srcIn),
            ),
          ],
        ),
        SizedBox(width: blockGap),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('${record.pulse}', maxLines: 1, overflow: TextOverflow.ellipsis, style: valueStyle),
            SizedBox(width: iconGap),
            SvgPicture.asset(
              'assets/activity.svg',
              width: iconSize,
              height: iconSize,
              colorFilter: ColorFilter.mode(iconColor, BlendMode.srcIn),
            ),
          ],
        ),
      ],
    );
  }
}
