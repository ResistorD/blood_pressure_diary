import 'package:flutter/material.dart';
import 'package:blood_pressure_diary/core/utils/l10n_extensions.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/theme/scale.dart';
import '../data/blood_pressure_model.dart';
import 'bloc/home_bloc.dart';
import 'bloc/home_state.dart';
import 'widgets/summary_card.dart';
import 'widgets/record_list_item.dart';
import '../../add_record/presentation/add_record_screen.dart';

enum _FilterPeriod { today, week, month, all }

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  _FilterPeriod _period = _FilterPeriod.week;

  // --- Лейблы периода
  String _periodLabel(_FilterPeriod p) {
    final l10n = context.l10n;
    switch (p) {
      case _FilterPeriod.today:
        return l10n.today;
      case _FilterPeriod.week:
        return l10n.week;
      case _FilterPeriod.month:
        return l10n.month;
      case _FilterPeriod.all:
        return l10n.allShort;
    }
  }

  // --- Склонение "запись/записи/записей"
  String _recordsWord(int n) {
    final l10n = context.l10n;
    final lang = Localizations.localeOf(context).languageCode;

    if (lang != 'ru') return l10n.recordsMany;

    final nAbs = n.abs() % 100;
    final n1 = nAbs % 10;

    if (nAbs >= 11 && nAbs <= 19) return l10n.recordsMany;
    if (n1 == 1) return l10n.recordsOne;
    if (n1 >= 2 && n1 <= 4) return l10n.recordsFew;
    return l10n.recordsMany;
  }

  // --- Фильтр записей
  List<BloodPressureRecord> _applyFilter(List<BloodPressureRecord> records) {
    final now = DateTime.now();

    switch (_period) {
      case _FilterPeriod.today:
        final d = DateTime(now.year, now.month, now.day);
        return records.where((r) {
          final rd = DateTime(r.dateTime.year, r.dateTime.month, r.dateTime.day);
          return rd == d;
        }).toList();

      case _FilterPeriod.week:
        final from = now.subtract(const Duration(days: 7));
        return records.where((r) => r.dateTime.isAfter(from)).toList();

      case _FilterPeriod.month:
        final from = now.subtract(const Duration(days: 30));
        return records.where((r) => r.dateTime.isAfter(from)).toList();

      case _FilterPeriod.all:
        return records;
    }
  }

  void _openEdit(BuildContext context, BloodPressureRecord record) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => AddRecordScreen(record: record)),
    );
  }

  double _bottomInset(BuildContext context) {
    final space = context.appSpace;
    final safeBottom = MediaQuery.paddingOf(context).bottom;

    final barH = dp(context, space.s72 - space.s2 - space.s1);
    final outer = dp(context, space.s80 + space.s6);
    final lift = outer / 2;

    return barH + lift + safeBottom + dp(context, space.s8);
  }

  @override
  Widget build(BuildContext context) {
    final safeTop = MediaQuery.of(context).padding.top;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final colors = context.appColors;
    final space = context.appSpace;
    final radii = context.appRadii;
    final appText = context.appText;

    final side = dp(context, space.s20);
    final blueH = dp(context, space.s160);
    final shelfH = dp(context, space.s80);
    final overlap = dp(context, space.s40 + space.s10);
    final headerTop = safeTop + dp(context, space.s20);

    final headerBg = isDark ? AppPalette.dark800 : AppPalette.blue700;
    final shelfBg = isDark ? AppPalette.dark700 : AppPalette.grey050;

    final dividerH = dp(context, space.s1) / dp(context, space.s2);
    final shelfDivider = isDark ? Colors.transparent : colors.divider;

    final shelfShadow = BoxShadow(
      offset: Offset(0, dp(context, space.s1)),
      blurRadius: dp(context, space.s4),
      color: colors.shadow,
    );

    final chipH = dp(context, space.s32);
    final chipR = dp(context, radii.r5);
    final chipHPad = dp(context, space.s10);
    final chipGap = dp(context, space.s4);
    final icon24 = dp(context, space.s24);

    final chipBg = isDark ? AppPalette.dark700 : AppPalette.blue500;
    final chipText = colors.textOnBrand;

    final titleStyle = TextStyle(
      fontFamily: appText.family,
      fontSize: sp(context, appText.fs26),
      fontWeight: appText.w600,
      color: colors.textOnBrand,
      height: 1.0,
    );

    final countStyle = TextStyle(
      fontFamily: appText.family,
      fontSize: sp(context, appText.fs16),
      fontWeight: appText.w500,
      color: isDark ? AppPalette.dark400 : AppPalette.blue300,
      height: 1.0,
    );

    final dateStyle = TextStyle(
      fontFamily: appText.family,
      fontSize: sp(context, appText.fs16),
      fontWeight: appText.w600,
      color: colors.textPrimary,
      height: 1.0,
    );

    final emptyStyle = TextStyle(
      fontFamily: appText.family,
      fontSize: sp(context, appText.fs16),
      fontWeight: appText.w600,
      color: colors.textPrimary,
      height: 1.0,
    );

    final bottomListPadding = _bottomInset(context);

    return BlocBuilder<HomeBloc, HomeState>(
      builder: (context, state) {
        final all = state is HomeLoaded ? state.records : const <BloodPressureRecord>[];
        final records = _applyFilter(all)..sort((a, b) => b.dateTime.compareTo(a.dateTime));
        final filteredCount = records.length;

        final lastRecord = all.isNotEmpty
            ? (List<BloodPressureRecord>.from(all)..sort((a, b) => b.dateTime.compareTo(a.dateTime))).first
            : null;

        final groups = _groupByDate(records);

        final header = SizedBox(
          height: blueH + shelfH,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned.fill(child: ColoredBox(color: headerBg)),
              Positioned(
                top: blueH,
                left: 0,
                right: 0,
                height: shelfH,
                child: Container(
                  decoration: BoxDecoration(
                    color: shelfBg,
                    boxShadow: [shelfShadow],
                  ),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: SizedBox(
                      height: dividerH,
                      child: ColoredBox(color: shelfDivider),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: side,
                right: side,
                top: headerTop,
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(context.l10n.myDiary, style: titleStyle),
                          SizedBox(height: dp(context, space.s20)),
                          Text(
                            '$filteredCount ${_recordsWord(filteredCount)}',
                            style: countStyle,
                          ),
                        ],
                      ),
                    ),
                    PopupMenuButton<_FilterPeriod>(
                      onSelected: (value) => setState(() => _period = value),
                      itemBuilder: (_) => [
                        PopupMenuItem(value: _FilterPeriod.today, child: Text(context.l10n.today)),
                        PopupMenuItem(value: _FilterPeriod.week, child: Text(context.l10n.week)),
                        PopupMenuItem(value: _FilterPeriod.month, child: Text(context.l10n.month)),
                        PopupMenuItem(value: _FilterPeriod.all, child: Text(context.l10n.allTime)),
                      ],
                      child: Container(
                        height: chipH,
                        padding: EdgeInsets.symmetric(horizontal: chipHPad),
                        decoration: BoxDecoration(
                          color: chipBg,
                          borderRadius: BorderRadius.circular(chipR),
                        ),
                        child: Row(
                          children: [
                            Text(_periodLabel(_period), style: TextStyle(color: chipText)),
                            SizedBox(width: chipGap),
                            SvgPicture.asset(
                              'assets/arrow_drop_down.svg',
                              width: icon24,
                              height: icon24,
                              colorFilter: ColorFilter.mode(chipText, BlendMode.srcIn),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );

        final list = CustomScrollView(
          slivers: [
            if (groups.isEmpty) ...[
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.only(top: dp(context, space.s24)),
                  child: Center(
                    child: Text(context.l10n.noRecordsForPeriod, style: emptyStyle),
                  ),
                ),
              ),
              SliverToBoxAdapter(child: SizedBox(height: bottomListPadding)),
            ] else ...[
              for (final entry in groups) ...[
                SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.only(right: side),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(_formatDate(entry.key), style: dateStyle),
                    ),
                  ),
                ),
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                        (context, i) {
                      final r = entry.value[i];
                      return Padding(
                        padding: EdgeInsets.fromLTRB(side, dp(context, space.s12), side, 0),
                        child: RecordListItem(
                          record: r,
                          onTap: () => _openEdit(context, r),
                        ),
                      );
                    },
                    childCount: entry.value.length,
                  ),
                ),
              ],
              SliverToBoxAdapter(child: SizedBox(height: bottomListPadding)),
            ],
          ],
        );

        return ColoredBox(
          color: colors.background,
          child: Column(
            children: [
              SizedBox(
                height: blueH + shelfH,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    header,
                    Positioned(
                      left: side,
                      right: side,
                      top: blueH - overlap,
                      child: SummaryCard(record: lastRecord),
                    ),
                  ],
                ),
              ),
              Expanded(child: list),
            ],
          ),
        );
      },
    );
  }

  List<MapEntry<DateTime, List<BloodPressureRecord>>> _groupByDate(List<BloodPressureRecord> records) {
    final map = <DateTime, List<BloodPressureRecord>>{};
    for (final r in records) {
      final d = DateTime(r.dateTime.year, r.dateTime.month, r.dateTime.day);
      map.putIfAbsent(d, () => []).add(r);
    }
    final keys = map.keys.toList()..sort((a, b) => b.compareTo(a));
    return [for (final k in keys) MapEntry(k, map[k]!)];
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    if (date == today) {
      return '${context.l10n.today}, ${DateFormat('d MMMM', Localizations.localeOf(context).languageCode).format(date)}';
    }
    return DateFormat('d MMMM yyyy', Localizations.localeOf(context).languageCode).format(date);
  }
}
