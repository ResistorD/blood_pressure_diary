import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/theme/scale.dart';
import '../../../l10n/generated/app_localizations.dart';

import 'bloc/profile_cubit.dart';
import 'bloc/profile_state.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  String tr(BuildContext context, {required String ru, required String en}) {
    final code = Localizations.localeOf(context).languageCode.toLowerCase();
    return code == 'ru' ? ru : en;
  }

  String providerTitle(BuildContext context, String provider) {
    switch (provider) {
      case 'google':
        return 'Google';
      case 'apple':
        return 'Apple';
      case 'email':
        return 'Email';
      default:
        return provider.isEmpty ? tr(context, ru: 'Аккаунт', en: 'Account') : provider;
    }
  }

  /// Поддержка двух режимов хранения:
  /// - если age выглядит как YYYYMMDD (>= 19000101) — считаем это датой рождения
  /// - иначе даты нет (вернем null)
  String? formatDob(BuildContext context, int stored) {
    if (stored < 19000101) return null;

    final s = stored.toString().padLeft(8, '0');
    final yyyy = int.tryParse(s.substring(0, 4));
    final mm = int.tryParse(s.substring(4, 6));
    final dd = int.tryParse(s.substring(6, 8));
    if (yyyy == null || mm == null || dd == null) return null;

    final dt = DateTime(yyyy, mm, dd);
    final locale = Localizations.localeOf(context).toString();
    return DateFormat.yMd(locale).format(dt);
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    final isDark = Theme.of(context).brightness == Brightness.dark;

    final colors = context.appColors;
    final space = context.appSpace;
    final radii = context.appRadii;
    final shadows = context.appShadow;
    final text = context.appText;

    final headerH = dp(context, space.s128);
    final side = dp(context, space.s20);

    final cardW = dp(context, space.w320);
    final cardR = dp(context, radii.r10);

    final innerW = cardW - dp(context, space.s24); // 296
    final fieldH = dp(context, space.s48);
    final fieldR = dp(context, radii.r10);

    final headerBg = isDark ? AppPalette.dark800 : AppPalette.blue700;
    final headerTopInset = MediaQuery.paddingOf(context).top;

    // UI-only: пример даты, форматируется по locale
    final locale = Localizations.localeOf(context).toString();
    final demoDob = DateFormat.yMd(locale).format(DateTime(1980, 12, 25));

    // Плотнее по Y
    final pad12 = dp(context, space.s12);
    final pad10 = dp(context, space.s10);
    final pad8 = dp(context, space.s8);
    final pad6 = dp(context, space.s6);
    final pad4 = dp(context, space.s4);
    final pad2 = dp(context, space.s2);

    final titleStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs26),
      fontWeight: text.w600,
      color: colors.textOnBrand,
      height: 1.0,
    );

    final sectionTitleStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs16),
      fontWeight: text.w600,
      color: colors.textPrimary,
      height: 1.0,
    );

    final hintStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs12),
      fontWeight: text.w400,
      color: colors.textPrimary,
      height: 1.0,
    );

    final labelStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs14),
      fontWeight: text.w400,
      color: colors.textPrimary,
      height: 1.0,
    );

    final valueStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs20),
      fontWeight: text.w500,
      color: colors.textPrimary,
      height: 1.0,
    );

    final privacyStyle = TextStyle(
      fontFamily: text.family,
      fontSize: sp(context, text.fs12),
      fontWeight: text.w400,
      color: colors.textPrimary,
      height: 1.0,
    );

    Widget primaryButton({
      required String title,
      String? subtitle,
      required Color bg,
      required Color fg,
      required VoidCallback onTap,
    }) {
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Container(
          height: fieldH,
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(fieldR),
          ),
          alignment: Alignment.center,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontFamily: text.family,
                  fontSize: sp(context, text.fs20),
                  fontWeight: text.w600,
                  color: fg,
                  height: 1.0,
                ),
              ),
              if (subtitle != null && subtitle.isNotEmpty) ...[
                SizedBox(height: dp(context, space.s2)),
                Text(subtitle, style: hintStyle.copyWith(color: fg), textAlign: TextAlign.center),
              ],
            ],
          ),
        ),
      );
    }

    Widget wideField({required String textValue}) {
      final bg = isDark ? colors.surfaceAlt : colors.background;
      return Container(
        height: fieldH,
        width: innerW,
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(fieldR),
        ),
        padding: EdgeInsets.symmetric(horizontal: dp(context, space.s12)),
        alignment: Alignment.centerLeft,
        child: Text(textValue, style: valueStyle),
      );
    }

    Widget valueBox({required String textValue}) {
      final w = dp(context, space.s120 + space.s16 + space.s1); // 137
      final bg = isDark ? colors.surfaceAlt : colors.background;

      return Container(
        height: fieldH,
        width: w,
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(fieldR),
        ),
        padding: EdgeInsets.symmetric(horizontal: dp(context, space.s12)),
        alignment: Alignment.centerRight,
        child: Text(textValue, style: valueStyle),
      );
    }

    Widget segPill({
      required String title,
      required bool selected,
      required VoidCallback onTap,
      required Color activeBg,
      required Color inactiveText,
      required Color activeText,
    }) {
      return Expanded(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: onTap,
          child: Container(
            height: fieldH,
            decoration: BoxDecoration(
              color: selected ? activeBg : Colors.transparent,
              borderRadius: BorderRadius.circular(fieldR),
            ),
            alignment: Alignment.center,
            child: Text(
              title,
              style: valueStyle.copyWith(color: selected ? activeText : inactiveText),
            ),
          ),
        ),
      );
    }

    Widget normsBlock({
      required String topValue,
      required String bottomValue,
    }) {
      final fieldBg = isDark ? colors.surfaceAlt : colors.background;
      final borderColor = fieldBg;
      final borderW = dp(context, space.s1);

      final labelLeftPad = dp(context, space.s12);
      final betweenRows = pad4;

      return Container(
        width: innerW,
        decoration: BoxDecoration(
          border: Border.all(color: borderColor, width: borderW),
          borderRadius: BorderRadius.circular(fieldR),
        ),
        padding: EdgeInsets.all(pad2),
        child: Column(
          children: [
            SizedBox(
              height: fieldH,
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(left: labelLeftPad),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(l10n.systolic, style: valueStyle),
                      ),
                    ),
                  ),
                  valueBox(textValue: topValue),
                ],
              ),
            ),
            SizedBox(height: betweenRows),
            SizedBox(
              height: fieldH,
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(left: labelLeftPad),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(l10n.diastolic, style: valueStyle),
                      ),
                    ),
                  ),
                  valueBox(textValue: bottomValue),
                ],
              ),
            ),
          ],
        ),
      );
    }

    Widget sheetItem({
      required BuildContext context,
      required String title,
      required VoidCallback onTap,
    }) {
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Container(
          height: fieldH,
          decoration: BoxDecoration(
            color: isDark ? colors.surfaceAlt : colors.background,
            borderRadius: BorderRadius.circular(fieldR),
          ),
          padding: EdgeInsets.symmetric(horizontal: dp(context, space.s12)),
          alignment: Alignment.centerLeft,
          child: Text(title, style: valueStyle),
        ),
      );
    }

    void showEmailInputSheet(BuildContext context) {
      final controller = TextEditingController();

      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (ctx) {
          final sheetBg = colors.surface;
          final sheetR = dp(context, radii.r10);
          final bottomInset = MediaQuery.viewInsetsOf(ctx).bottom;

          return SafeArea(
            child: Padding(
              padding: EdgeInsets.only(
                left: dp(context, space.s12),
                right: dp(context, space.s12),
                bottom: dp(context, space.s12) + bottomInset,
              ),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: sheetBg,
                  borderRadius: BorderRadius.circular(sheetR),
                  boxShadow: [shadows.card],
                ),
                child: Padding(
                  padding: EdgeInsets.all(dp(context, space.s12)),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Email'),
                      SizedBox(height: dp(context, space.s8)),
                      Container(
                        height: fieldH,
                        decoration: BoxDecoration(
                          color: isDark ? colors.surfaceAlt : colors.background,
                          borderRadius: BorderRadius.circular(fieldR),
                        ),
                        padding: EdgeInsets.symmetric(horizontal: dp(context, space.s12)),
                        alignment: Alignment.centerLeft,
                        child: TextField(
                          controller: controller,
                          keyboardType: TextInputType.emailAddress,
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                            isCollapsed: true,
                          ),
                          style: valueStyle,
                        ),
                      ),
                      SizedBox(height: dp(context, space.s12)),
                      SizedBox(
                        width: double.infinity,
                        child: primaryButton(
                          title: tr(context, ru: 'Подключить', en: 'Link'),
                          bg: isDark ? AppPalette.dark900 : AppPalette.blue900,
                          fg: isDark ? colors.textPrimary : colors.textOnBrand,
                          onTap: () {
                            final email = controller.text.trim();
                            if (email.isEmpty) return;
                            context.read<ProfileCubit>().linkAccount(provider: 'email', email: email);
                            Navigator.pop(ctx);
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      );
    }

    void showAccountLinkSheet(BuildContext context) {
      showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        builder: (ctx) {
          final sheetBg = colors.surface;
          final sheetR = dp(context, radii.r10);

          return SafeArea(
            child: Padding(
              padding: EdgeInsets.all(dp(context, space.s12)),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: sheetBg,
                  borderRadius: BorderRadius.circular(sheetR),
                  boxShadow: [shadows.card],
                ),
                child: Padding(
                  padding: EdgeInsets.all(dp(context, space.s12)),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tr(context, ru: 'Выберите способ входа', en: 'Choose sign-in method'),
                        style: sectionTitleStyle,
                      ),
                      SizedBox(height: dp(context, space.s12)),
                      sheetItem(
                        context: context,
                        title: 'Email',
                        onTap: () {
                          Navigator.pop(ctx);
                          showEmailInputSheet(context);
                        },
                      ),
                      SizedBox(height: dp(context, space.s8)),
                      sheetItem(
                        context: context,
                        title: 'Google',
                        onTap: () {
                          context.read<ProfileCubit>().linkAccount(provider: 'google', email: '');
                          Navigator.pop(ctx);
                        },
                      ),
                      SizedBox(height: dp(context, space.s8)),
                      sheetItem(
                        context: context,
                        title: 'Apple',
                        onTap: () {
                          context.read<ProfileCubit>().linkAccount(provider: 'apple', email: '');
                          Navigator.pop(ctx);
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      );
    }

    return Scaffold(
      backgroundColor: colors.background,
      body: BlocBuilder<ProfileCubit, ProfileState>(
        builder: (context, state) {
          if (state is ProfileInitial) {
            context.read<ProfileCubit>().loadProfile();
          }
          if (state is ProfileLoading) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state is! ProfileLoaded) {
            return const SizedBox.shrink();
          }

          final profile = state.profile;
          final isLoggedIn = profile.accountLinked;

          final cardBg = colors.surface;

          final innerZoneBg = isDark ? cardBg : AppPalette.grey050;
          final innerZoneBorderColor = isDark ? AppPalette.dark800 : colors.background;

          final accountBtnBg = isDark
              ? (isLoggedIn ? colors.surfaceAlt : AppPalette.dark900)
              : (isLoggedIn ? AppPalette.blue500 : AppPalette.blue900);

          final accountBtnFg = isDark ? colors.textPrimary : colors.textOnBrand;

          final segBg = isDark ? colors.surfaceAlt : colors.background;
          final segActiveBg = colors.surface;
          final segText = colors.textPrimary;

          final bottomPad = dp(context, space.s80);

          final accountLine = profile.accountEmail.trim().isNotEmpty
              ? profile.accountEmail.trim()
              : providerTitle(context, profile.accountProvider);

          final displayedDob = formatDob(context, profile.age) ?? demoDob;

          return Column(
            children: [
              Container(
                height: headerH,
                width: double.infinity,
                color: headerBg,
                padding: EdgeInsets.only(
                  left: side,
                  right: side,
                  top: headerTopInset + dp(context, space.s20),
                ),
                alignment: Alignment.centerLeft,
                child: Text(l10n.profile, style: titleStyle),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.only(
                    left: side,
                    right: side,
                    top: pad12,
                    bottom: bottomPad,
                  ),
                  child: Column(
                    children: [
                      // ---- Аккаунт
                      SizedBox(
                        width: cardW,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(cardR),
                            boxShadow: [shadows.card],
                          ),
                          child: Padding(
                            padding: EdgeInsets.all(pad12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(tr(context, ru: 'Аккаунт', en: 'Account'), style: sectionTitleStyle),
                                SizedBox(height: pad6),
                                Container(
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    color: innerZoneBg,
                                    borderRadius: BorderRadius.circular(cardR),
                                    border: isDark
                                        ? Border.all(
                                      color: innerZoneBorderColor,
                                      width: dp(context, space.s1),
                                    )
                                        : null,
                                  ),
                                  padding: EdgeInsets.symmetric(horizontal: pad12, vertical: pad10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      if (!isLoggedIn) ...[
                                        Text(
                                          tr(context, ru: 'Вы не вошли в аккаунт', en: 'You are not signed in'),
                                          style: hintStyle,
                                        ),
                                        SizedBox(height: pad8),
                                        Center(
                                          child: SizedBox(
                                            width: dp(context, space.w320 - space.s48), // 272
                                            child: primaryButton(
                                              title: tr(context, ru: 'Войти', en: 'Sign in'),
                                              bg: accountBtnBg,
                                              fg: accountBtnFg,
                                              onTap: () => showAccountLinkSheet(context),
                                            ),
                                          ),
                                        ),
                                      ] else ...[
                                        Text(
                                          tr(context, ru: 'Аккаунт подключен', en: 'Account linked'),
                                          style: hintStyle,
                                        ),
                                        SizedBox(height: pad4),
                                        Text(accountLine, style: valueStyle),
                                        SizedBox(height: pad8),
                                        Center(
                                          child: SizedBox(
                                            width: dp(context, space.w320 - space.s48), // 272
                                            child: primaryButton(
                                              title: tr(context, ru: 'Выйти', en: 'Sign out'),
                                              bg: accountBtnBg,
                                              fg: accountBtnFg,
                                              onTap: () => context.read<ProfileCubit>().unlinkAccount(),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      SizedBox(height: pad12),

                      // ---- Профиль
                      SizedBox(
                        width: cardW,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(cardR),
                            boxShadow: [shadows.card],
                          ),
                          child: Padding(
                            padding: EdgeInsets.all(pad12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(l10n.name, style: labelStyle),
                                SizedBox(height: pad6),
                                wideField(
                                  textValue: profile.name.isEmpty ? tr(context, ru: 'Дмитрий', en: 'Dmitry') : profile.name,
                                ),

                                SizedBox(height: pad10),

                                Row(
                                  children: [
                                    Expanded(child: Text(l10n.gender, style: labelStyle)),
                                    SizedBox(width: dp(context, space.s20)),
                                    Expanded(
                                      child: Align(
                                        alignment: Alignment.centerRight,
                                        child: Text(tr(context, ru: 'Дата рождения', en: 'Date of birth'), style: labelStyle),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: pad6),
                                Row(
                                  children: [
                                    SizedBox(
                                      width: dp(context, (space.w320 - space.s40) / 2), // 140
                                      child: Container(
                                        height: fieldH,
                                        decoration: BoxDecoration(
                                          color: segBg,
                                          borderRadius: BorderRadius.circular(fieldR),
                                        ),
                                        padding: EdgeInsets.all(pad4),
                                        child: Row(
                                          children: [
                                            segPill(
                                              title: tr(context, ru: 'М', en: 'M'),
                                              selected: profile.gender == 'male',
                                              activeBg: segActiveBg,
                                              inactiveText: segText,
                                              activeText: segText,
                                              onTap: () => context.read<ProfileCubit>().updateProfile(gender: 'male'),
                                            ),
                                            SizedBox(width: pad4),
                                            segPill(
                                              title: tr(context, ru: 'Ж', en: 'F'),
                                              selected: profile.gender == 'female',
                                              activeBg: segActiveBg,
                                              inactiveText: segText,
                                              activeText: segText,
                                              onTap: () => context.read<ProfileCubit>().updateProfile(gender: 'female'),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    const Spacer(),
                                    valueBox(textValue: displayedDob),
                                  ],
                                ),

                                SizedBox(height: pad10),

                                Text(tr(context, ru: 'Целевое давление', en: 'Target pressure'), style: labelStyle),
                                SizedBox(height: pad6),
                                normsBlock(
                                  topValue: profile.targetSystolic.toString(),
                                  bottomValue: profile.targetDiastolic.toString(),
                                ),

                                SizedBox(height: pad12),

                                Center(
                                  child: SizedBox(
                                    width: dp(context, space.w320 - space.s48), // 272
                                    child: primaryButton(
                                      title: tr(context, ru: 'Купить Premium', en: 'Buy Premium'),
                                      subtitle: tr(context, ru: 'Разовый платёж', en: 'One-time payment'),
                                      bg: isDark ? AppPalette.dark900 : AppPalette.blue900,
                                      fg: isDark ? colors.textPrimary : colors.textOnBrand,
                                      onTap: () {},
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      SizedBox(height: pad12),
                      Text(
                        tr(context, ru: 'Политика конфиденциальности', en: 'Privacy Policy'),
                        style: privacyStyle,
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
