import 'package:flutter_test/flutter_test.dart';
import 'package:blood_pressure_diary/core/utils/smart_input_engine.dart';
import 'package:blood_pressure_diary/core/utils/input_field.dart';

void main() {
  group('SmartInputEngine - shouldAutoAdvance', () {
    test('should auto-advance after 3 digits in systolic (120)', () {
      expect(
        SmartInputEngine.shouldAutoAdvance(
          field: InputField.systolic,
          currentText: '120',
          systolicValue: 120,
        ),
        true,
      );
    });

    test('should NOT auto-advance with 2 digits in systolic', () {
      expect(
        SmartInputEngine.shouldAutoAdvance(
          field: InputField.systolic,
          currentText: '12',
          systolicValue: 12,
        ),
        false,
      );
    });

    test('should auto-advance after 2 digits in diastolic', () {
      expect(
        SmartInputEngine.shouldAutoAdvance(
          field: InputField.diastolic,
          currentText: '80',
          systolicValue: 120,
        ),
        true,
      );
    });

    test('should auto-advance after 2 digits in pulse', () {
      expect(
        SmartInputEngine.shouldAutoAdvance(
          field: InputField.pulse,
          currentText: '70',
          systolicValue: 120,
        ),
        true,
      );
    });

    test('should NOT auto-advance for InputField.none', () {
      expect(
        SmartInputEngine.shouldAutoAdvance(
          field: InputField.none,
          currentText: '123',
          systolicValue: 120,
        ),
        false,
      );
    });
  });

  group('SmartInputEngine - isDigitAllowed', () {
    test('should allow digits 0-9 for empty systolic', () {
      for (var digit in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']) {
        expect(
          SmartInputEngine.isDigitAllowed(
            field: InputField.systolic,
            currentText: '',
            digit: digit,
            systolicValue: null,
          ),
          true,
          reason: 'Digit $digit should be allowed for empty systolic',
        );
      }
    });

    test('should NOT allow invalid digits that make systolic > 300', () {
      // Starting with "30", only 0 should be allowed (300 is max)
      expect(
        SmartInputEngine.isDigitAllowed(
          field: InputField.systolic,
          currentText: '30',
          digit: '0',
          systolicValue: 30,
        ),
        true,
      );

      expect(
        SmartInputEngine.isDigitAllowed(
          field: InputField.systolic,
          currentText: '30',
          digit: '1',
          systolicValue: 30,
        ),
        false,
        reason: '301 > 300, should be disallowed',
      );
    });

    test('should limit diastolic based on systolic value', () {
      // If systolic is 120, diastolic can't be >= 120
      expect(
        SmartInputEngine.isDigitAllowed(
          field: InputField.diastolic,
          currentText: '8',
          digit: '0',
          systolicValue: 120,
        ),
        true,
        reason: '80 < 120, should be allowed',
      );

      expect(
        SmartInputEngine.isDigitAllowed(
          field: InputField.diastolic,
          currentText: '12',
          digit: '0',
          systolicValue: 120,
        ),
        false,
        reason: '120 >= 120, should be disallowed',
      );
    });

    test('should allow pulse up to 250', () {
      expect(
        SmartInputEngine.isDigitAllowed(
          field: InputField.pulse,
          currentText: '25',
          digit: '0',
          systolicValue: 120,
        ),
        true,
        reason: '250 is max pulse',
      );

      expect(
        SmartInputEngine.isDigitAllowed(
          field: InputField.pulse,
          currentText: '25',
          digit: '1',
          systolicValue: 120,
        ),
        false,
        reason: '251 > 250, should be disallowed',
      );
    });
  });
}
