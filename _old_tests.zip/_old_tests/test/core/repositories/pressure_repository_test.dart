import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:blood_pressure_diary/core/repositories/pressure_repository.dart';
import 'package:blood_pressure_diary/core/database/isar_service.dart';
import 'package:blood_pressure_diary/features/home/data/blood_pressure_model.dart';

@GenerateMocks([IsarService])
//import 'pressure_repository_test.mocks.dart';

void main() {
  late PressureRepository repository;
  late MockIsarService mockIsarService;

  setUp(() {
    mockIsarService = MockIsarService();
    repository = PressureRepository(mockIsarService);
  });

  group('PressureRepository Validation Tests', () {
    test('should throw InvalidRecordException when systolic < 60', () async {
      final record = BloodPressureRecord()
        ..systolic = 50
        ..diastolic = 80
        ..pulse = 70
        ..dateTime = DateTime.now();

      expect(
        () => repository.addRecord(record),
        throwsA(isA<InvalidRecordException>()),
      );

      verifyNever(mockIsarService.saveRecord(any));
    });

    test('should throw InvalidRecordException when systolic > 300', () async {
      final record = BloodPressureRecord()
        ..systolic = 350
        ..diastolic = 80
        ..pulse = 70
        ..dateTime = DateTime.now();

      expect(
        () => repository.addRecord(record),
        throwsA(isA<InvalidRecordException>()),
      );
    });

    test('should throw InvalidRecordException when diastolic < 40', () async {
      final record = BloodPressureRecord()
        ..systolic = 120
        ..diastolic = 30
        ..pulse = 70
        ..dateTime = DateTime.now();

      expect(
        () => repository.addRecord(record),
        throwsA(isA<InvalidRecordException>()),
      );
    });

    test('should throw InvalidRecordException when diastolic > 200', () async {
      final record = BloodPressureRecord()
        ..systolic = 250
        ..diastolic = 220
        ..pulse = 70
        ..dateTime = DateTime.now();

      expect(
        () => repository.addRecord(record),
        throwsA(isA<InvalidRecordException>()),
      );
    });

    test('should throw InvalidRecordException when pulse < 30', () async {
      final record = BloodPressureRecord()
        ..systolic = 120
        ..diastolic = 80
        ..pulse = 20
        ..dateTime = DateTime.now();

      expect(
        () => repository.addRecord(record),
        throwsA(isA<InvalidRecordException>()),
      );
    });

    test('should throw InvalidRecordException when pulse > 250', () async {
      final record = BloodPressureRecord()
        ..systolic = 120
        ..diastolic = 80
        ..pulse = 300
        ..dateTime = DateTime.now();

      expect(
        () => repository.addRecord(record),
        throwsA(isA<InvalidRecordException>()),
      );
    });

    test('should throw InvalidRecordException when systolic <= diastolic', () async {
      final record = BloodPressureRecord()
        ..systolic = 80
        ..diastolic = 80
        ..pulse = 70
        ..dateTime = DateTime.now();

      expect(
        () => repository.addRecord(record),
        throwsA(isA<InvalidRecordException>()),
      );
    });

    test('should save valid record', () async {
      final record = BloodPressureRecord()
        ..systolic = 120
        ..diastolic = 80
        ..pulse = 70
        ..dateTime = DateTime.now();

      when(mockIsarService.saveRecord(any)).thenAnswer((_) async => {});

      await repository.addRecord(record);

      verify(mockIsarService.saveRecord(record)).called(1);
    });
  });

  group('PressureRepository Caching Tests', () {
    test('should cache records after first getAllRecords call', () async {
      final mockRecords = [
        BloodPressureRecord()
          ..systolic = 120
          ..diastolic = 80
          ..pulse = 70
          ..dateTime = DateTime.now(),
      ];

      when(mockIsarService.getAllRecords()).thenAnswer((_) async => mockRecords);

      // First call - should fetch from service
      final result1 = await repository.getAllRecords();
      expect(result1, mockRecords);
      verify(mockIsarService.getAllRecords()).called(1);

      // Second call - should return from cache
      final result2 = await repository.getAllRecords();
      expect(result2, mockRecords);
      verifyNever(mockIsarService.getAllRecords());
    });

    test('should invalidate cache after addRecord', () async {
      final mockRecords = [
        BloodPressureRecord()
          ..systolic = 120
          ..diastolic = 80
          ..pulse = 70
          ..dateTime = DateTime.now(),
      ];

      when(mockIsarService.getAllRecords()).thenAnswer((_) async => mockRecords);
      when(mockIsarService.saveRecord(any)).thenAnswer((_) async => {});

      // Populate cache
      await repository.getAllRecords();
      verify(mockIsarService.getAllRecords()).called(1);

      // Add record (should invalidate cache)
      final newRecord = BloodPressureRecord()
        ..systolic = 130
        ..diastolic = 85
        ..pulse = 75
        ..dateTime = DateTime.now();

      await repository.addRecord(newRecord);

      // Next getAllRecords should fetch from service again
      await repository.getAllRecords();
      verify(mockIsarService.getAllRecords()).called(1);
    });

    test('should invalidate cache after deleteRecord', () async {
      final mockRecords = [
        BloodPressureRecord()
          ..id = 1
          ..systolic = 120
          ..diastolic = 80
          ..pulse = 70
          ..dateTime = DateTime.now(),
      ];

      when(mockIsarService.getAllRecords()).thenAnswer((_) async => mockRecords);
      when(mockIsarService.deleteRecord(any)).thenAnswer((_) async => {});

      // Populate cache
      await repository.getAllRecords();

      // Delete record
      await repository.deleteRecord(1);

      // Next getAllRecords should fetch from service again
      await repository.getAllRecords();
      verify(mockIsarService.getAllRecords()).called(2);
    });
  });
}
