import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:blood_pressure_diary/features/home/presentation/home_screen.dart';
import 'package:blood_pressure_diary/features/home/presentation/bloc/home_bloc.dart';
import 'package:blood_pressure_diary/features/home/presentation/bloc/home_state.dart';
import 'package:blood_pressure_diary/features/home/data/blood_pressure_model.dart';
import 'package:blood_pressure_diary/core/repositories/pressure_repository.dart';

@GenerateMocks([PressureRepository])
//import 'home_screen_test.mocks.dart';

void main() {
  late MockPressureRepository mockRepository;

  setUp(() {
    mockRepository = MockPressureRepository();
  });

  Widget createWidgetUnderTest() {
    return MaterialApp(
      home: BlocProvider<HomeBloc>(
        create: (_) => HomeBloc(mockRepository),
        child: const HomeScreen(),
      ),
    );
  }

  testWidgets('HomeScreen displays diary title', (WidgetTester tester) async {
    when(mockRepository.getAllRecordsStream()).thenAnswer(
      (_) => Stream.value([]),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pumpAndSettle();

    // Should display either 'Мой дневник' (ru) or 'My diary' (en)
    expect(
      find.textContaining('дневник', findRichText: true).evaluate().isNotEmpty ||
          find.textContaining('diary', findRichText: true).evaluate().isNotEmpty,
      true,
    );
  });

  testWidgets('HomeScreen displays empty state when no records', (WidgetTester tester) async {
    when(mockRepository.getAllRecordsStream()).thenAnswer(
      (_) => Stream.value([]),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pumpAndSettle();

    // Should show "0 записей" or "0 records"
    expect(
      find.textContaining('0', findRichText: true).evaluate().isNotEmpty,
      true,
    );
  });

  testWidgets('HomeScreen displays records list when data available', (WidgetTester tester) async {
    final mockRecords = [
      BloodPressureRecord()
        ..id = 1
        ..systolic = 120
        ..diastolic = 80
        ..pulse = 70
        ..dateTime = DateTime.now(),
      BloodPressureRecord()
        ..id = 2
        ..systolic = 130
        ..diastolic = 85
        ..pulse = 75
        ..dateTime = DateTime.now().subtract(const Duration(hours: 2)),
    ];

    when(mockRepository.getAllRecordsStream()).thenAnswer(
      (_) => Stream.value(mockRecords),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pumpAndSettle();

    // Should display "2 записи" or "2 records"
    expect(
      find.textContaining('2', findRichText: true).evaluate().isNotEmpty,
      true,
    );

    // Should display systolic values
    expect(find.text('120'), findsOneWidget);
    expect(find.text('130'), findsOneWidget);
  });

  testWidgets('HomeScreen filter button is visible', (WidgetTester tester) async {
    when(mockRepository.getAllRecordsStream()).thenAnswer(
      (_) => Stream.value([]),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pumpAndSettle();

    // Should find dropdown icon for filter
    expect(find.byType(PopupMenuButton<dynamic>), findsOneWidget);
  });

  testWidgets('HomeScreen can change filter period', (WidgetTester tester) async {
    final mockRecords = [
      BloodPressureRecord()
        ..id = 1
        ..systolic = 120
        ..diastolic = 80
        ..pulse = 70
        ..dateTime = DateTime.now(),
      BloodPressureRecord()
        ..id = 2
        ..systolic = 130
        ..diastolic = 85
        ..pulse = 75
        ..dateTime = DateTime.now().subtract(const Duration(days: 10)),
    ];

    when(mockRepository.getAllRecordsStream()).thenAnswer(
      (_) => Stream.value(mockRecords),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pumpAndSettle();

    // Default filter is "Week" - should show both records
    expect(
      find.textContaining('2', findRichText: true).evaluate().isNotEmpty,
      true,
    );

    // Tap filter button
    await tester.tap(find.byType(PopupMenuButton<dynamic>));
    await tester.pumpAndSettle();

    // Should show filter options (Today, Week, Month, All)
    // Try to find "Today" or "Сегодня"
    final todayFinder = find.text('Today').evaluate().isNotEmpty
        ? find.text('Today')
        : find.text('Сегодня');

    expect(todayFinder, findsOneWidget);

    // Select "Today" filter
    await tester.tap(todayFinder);
    await tester.pumpAndSettle();

    // Now should show only 1 record (from today)
    expect(
      find.textContaining('1', findRichText: true).evaluate().isNotEmpty,
      true,
    );
  });
}
